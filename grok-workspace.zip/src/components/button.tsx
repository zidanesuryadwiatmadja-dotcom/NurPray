import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

const buttonVariants = cva(
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45",
  {
    variants: {
      tone: {
        jade: "bg-jade text-surface",
        soft: "bg-jade-soft text-ink",
        gold: "bg-gold-soft text-ink",
        line: "border border-line bg-surface text-ink",
        ghost: "bg-transparent text-ink",
      },
    },
    defaultVariants: { tone: "jade" },
  },
);

type Props = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean };

export function Button({ className, tone, asChild, type, ...props }: Props) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      className={cn(buttonVariants({ tone }), className)}
      type={asChild ? undefined : (type ?? "button")}
      {...props}
    />
  );
}

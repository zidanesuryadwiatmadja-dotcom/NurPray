import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, House, Library, ListChecks } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { KincirMark } from "@/components/kincir-mark";
import { cn } from "@/lib/cn";
import { formatCxp, formatPoin } from "@/lib/format";
import { useApp } from "@/lib/store";

const TABS = [
  { to: "/", label: "Beranda", icon: House, exact: true },
  { to: "/misi", label: "Misi", icon: ListChecks, exact: false },
  { to: "/kincir", label: "Kincir", icon: null, exact: false },
  { to: "/quran", label: "Quran", icon: BookOpen, exact: false },
  { to: "/motivasi", label: "Renungan", icon: Library, exact: false },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const points = useApp((s) => s.points);
  const cxp = useApp((s) => s.cxp);
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    void Promise.resolve(useApp.persist.rehydrate()).then(() => {
      useApp.getState().claimIfReady();
    });
  }, []);

  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/95 backdrop-blur-sm">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex min-h-11 items-center gap-2">
            <span className="flex size-10 items-center justify-center rounded-full bg-jade text-surface">
              <KincirMark className="size-7 text-gold-soft" />
            </span>
            <span>
              <span className="block text-sm font-semibold leading-tight">NurPray</span>
              <span className="block text-xs text-muted">Islamic Motivation Pray</span>
            </span>
          </Link>
          <Link to="/hadiah" className="ml-auto min-h-11 rounded-full px-2 py-1 text-right leading-tight">
            <span className="block text-sm font-semibold tabular-nums">{formatPoin(points)} poin</span>
            <span className="block text-xs text-muted tabular-nums">{formatCxp(cxp)} CXP</span>
          </Link>
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl px-4 py-5 pb-28">{children}</main>
      <nav className="nav-pad fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface" aria-label="Utama">
        <ul className="mx-auto flex w-full max-w-3xl">
          {TABS.map((tab) => {
            const on = tab.exact ? path === tab.to : path === tab.to || path.startsWith(`${tab.to}/`);
            const Icon = tab.icon;
            return (
              <li key={tab.to} className="flex-1">
                <Link
                  to={tab.to}
                  aria-current={on ? "page" : undefined}
                  className={cn(
                    "flex min-h-16 flex-col items-center justify-center gap-1 text-xs",
                    on ? "text-jade" : "text-muted",
                  )}
                >
                  {Icon ? <Icon className="size-5" aria-hidden="true" /> : <KincirMark className={cn("size-6", on ? "text-jade" : "text-gold")} />}
                  {tab.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

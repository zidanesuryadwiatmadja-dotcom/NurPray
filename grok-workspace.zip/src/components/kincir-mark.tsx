import { cn } from "@/lib/cn";

export function KincirMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 80 80" className={cn("text-gold", className)} aria-hidden="true">
      <circle cx="40" cy="40" r="36" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="40" cy="40" r="27" fill="none" stroke="currentColor" strokeWidth="0.7" />
      {Array.from({ length: 8 }, (_, i) => (
        <ellipse
          key={i}
          cx="40"
          cy="40"
          rx="6.5"
          ry="24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.15"
          transform={`rotate(${i * 45} 40 40)`}
        />
      ))}
      <circle cx="40" cy="40" r="4.2" fill="currentColor" />
    </svg>
  );
}

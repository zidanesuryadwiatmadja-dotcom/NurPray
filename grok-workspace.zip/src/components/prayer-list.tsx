import { Check } from "lucide-react";
import { cn } from "@/lib/cn";
import { inWindow, PRAYERS, type PrayerId } from "@/lib/mission";
import { useApp } from "@/lib/store";
import { usePrayerTimes } from "@/lib/use-prayer-times";

export function PrayerList({ today }: { today: string | null }) {
  const logs = useApp((s) => s.logs);
  const start = useApp((s) => s.missionStart);
  const city = useApp((s) => s.city);
  const toggle = useApp((s) => s.togglePrayer);
  const clock = usePrayerTimes(city);
  const open = inWindow(start, today);
  const done = new Set<PrayerId>(today ? (logs[today] ?? []) : []);

  return (
    <div className="grid gap-2">
      {PRAYERS.map((prayer) => {
        const checked = done.has(prayer.id);
        const time = clock.times?.[prayer.key]?.slice(0, 5);
        const body = (
          <>
            <span>
              <span className="block font-semibold">{prayer.label}</span>
              <span className={cn("block text-sm", checked ? "text-ink" : "text-muted")}>
                {time ?? "Waktu menyusul"}
                {city ? ` · ${city}` : ""}
              </span>
            </span>
            <span className={cn("inline-flex items-center gap-1 text-sm font-semibold", checked ? "text-jade" : "text-muted")}>
              {checked ? <Check className="size-4" aria-hidden="true" /> : null}
              {checked ? "Sudah" : open ? "Catat" : "Jadwal"}
            </span>
          </>
        );
        if (!open) {
          return (
            <div key={prayer.id} className="card flex min-h-14 items-center justify-between px-4">
              {body}
            </div>
          );
        }
        return (
          <button
            key={prayer.id}
            type="button"
            disabled={!today || checked}
            onClick={() => toggle(prayer.id)}
            className={cn(
              "card flex min-h-14 w-full items-center justify-between px-4 text-left",
              checked && "border-jade bg-jade-soft disabled:opacity-100",
            )}
          >
            {body}
          </button>
        );
      })}
    </div>
  );
}

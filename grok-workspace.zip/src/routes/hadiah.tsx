import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Lock } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/button";
import { formatCxp, formatPoin } from "@/lib/format";
import { BONUS_CXP, BONUS_POINTS, PRAYER_POINTS, SHOP_CXP, SHOP_POINTS } from "@/lib/mission";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/hadiah")({ component: HadiahPage });

const PERKS = [
  "Kincir ayat tanpa batas harian",
  "Enam qari murottal, bukan hanya satu",
  "Mode malam untuk mushaf",
  "Penanda ayat tanpa batas",
  "Simpan renungan favorit tanpa batas",
  "Lencana QuranKu di beranda",
];

function HadiahPage() {
  const points = useApp((s) => s.points);
  const cxp = useApp((s) => s.cxp);
  const owned = useApp((s) => s.quranKu);
  const buy = useApp((s) => s.buyQuranKu);
  const [msg, setMsg] = useState("");
  const poinPct = Math.min(100, (points / SHOP_POINTS) * 100);
  const cxpPct = Math.min(100, (cxp / SHOP_CXP) * 100);
  const shortPoin = Math.max(0, SHOP_POINTS - points);
  const shortCxp = Math.max(0, SHOP_CXP - cxp);

  return (
    <div className="grid gap-4">
      <header>
        <h1 className="text-2xl font-semibold leading-tight">Tukar QuranKu</h1>
        <p className="mt-2 text-sm text-muted">
          Hadiah ini hidup di dalam NurPray. Tidak ada berkas APK dan tidak ada tautan unduhan, supaya yang kamu buka benar-benar mushaf, bukan berkas asing.
        </p>
      </header>

      <section className="card px-5 py-5">
        <p className="text-xs font-semibold tracking-wide text-gold">Premium</p>
        <h2 className="mt-1 text-xl font-semibold">QuranKu</h2>
        <p className="mt-2 text-sm">
          Mushaf 114 surat tetap bisa dibaca tanpa menukar apa pun. QuranKu menambah perlengkapan bacanya.
        </p>
        <ul className="mt-4 grid gap-2">
          {PERKS.map((perk) => (
            <li key={perk} className="flex items-start gap-2 text-sm">
              {owned ? <Check className="mt-0.5 size-4 shrink-0 text-jade" /> : <Lock className="mt-0.5 size-4 shrink-0 text-gold" />}
              <span>{perk}</span>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-lg font-semibold tabular-nums">
          {formatPoin(SHOP_POINTS)} poin + {formatCxp(SHOP_CXP)} CXP
        </p>
        <div className="mt-4 grid gap-3">
          <Meter label="Poinmu" value={`${formatPoin(points)} / ${formatPoin(SHOP_POINTS)}`} pct={poinPct} />
          <Meter label="CXP-mu" value={`${formatCxp(cxp)} / ${formatCxp(SHOP_CXP)}`} pct={cxpPct} />
        </div>
        {owned ? (
          <p className="mt-4 text-sm">QuranKu aktif di perangkat ini. Buka mushaf, pilih qari, atau putar kincir sepuasnya.</p>
        ) : (
          <>
            {shortPoin > 0 || shortCxp > 0 ? (
              <p className="mt-4 text-sm text-muted">
                {shortPoin > 0 ? `Poin kurang ${formatPoin(shortPoin)}. ` : ""}
                {shortCxp > 0 ? `CXP kurang ${formatCxp(shortCxp)}.` : ""}
              </p>
            ) : (
              <p className="mt-4 text-sm">Saldo sudah cukup untuk menukar.</p>
            )}
            <Button
              className="mt-4"
              onClick={() => {
                const result = buy();
                setMsg(
                  result === "ok"
                    ? "QuranKu sekarang aktif."
                    : result === "owned"
                      ? "Sudah aktif."
                      : "Poin atau CXP belum mencapai batas minimal.",
                );
              }}
            >
              Tukar dengan poin
            </Button>
          </>
        )}
        {msg ? <p className="mt-3 text-sm">{msg}</p> : null}
      </section>

      <section className="card px-5 py-5 text-sm">
        <h2 className="text-lg font-semibold">Jalan tercepat</h2>
        <p className="mt-2">
          Satu sholat tercatat memberi {formatPoin(PRAYER_POINTS)} poin. Itu saja belum cukup. Siklus 14 hari tanpa bolong menambah {formatPoin(BONUS_POINTS)} poin dan {formatCxp(BONUS_CXP)} CXP — baru di situ QuranKu bisa ditukar.
        </p>
        <Button asChild tone="line" className="mt-4">
          <Link to="/misi">Ke papan misi</Link>
        </Button>
      </section>
    </div>
  );
}

function Meter({ label, value, pct }: { label: string; value: string; pct: number }) {
  return (
    <div>
      <div className="mb-1 flex justify-between gap-3 text-xs text-muted">
        <span>{label}</span>
        <span className="tabular-nums">{value}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-gold-soft">
        <div className="h-full bg-jade" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

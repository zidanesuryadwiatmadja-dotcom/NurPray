import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/button";
import { METHODS, PANTI, pantiById } from "@/lib/charity";
import { cn } from "@/lib/cn";
import { formatRupiah } from "@/lib/format";
import { NIAT_POINTS } from "@/lib/mission";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/sedekah")({ component: SedekahPage });

const PRESETS = [10000, 25000, 50000, 100000];

function SedekahPage() {
  const niats = useApp((s) => s.niats);
  const addNiat = useApp((s) => s.addNiat);
  const [pantiId, setPantiId] = useState<string>(PANTI[0].id);
  const [nominal, setNominal] = useState("10000");
  const [method, setMethod] = useState<(typeof METHODS)[number]>("Dana");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [receipt, setReceipt] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  function submit() {
    const amount = Number(nominal.replace(/\D/g, ""));
    if (!Number.isInteger(amount) || amount < 1000 || amount > 100_000_000) {
      setError("Isi nominal antara Rp1.000 dan Rp100.000.000.");
      setReceipt(null);
      return;
    }
    const place = pantiById(pantiId);
    if (!place) {
      setError("Pilih panti terlebih dahulu.");
      return;
    }
    const result = addNiat({ pantiId, nominal: amount, method, note });
    const when = new Date().toLocaleString("id-ID");
    const code = `NP-${Date.now().toString(36).toUpperCase()}`;
    const text = [
      "Nota niat sedekah NurPray",
      place.name,
      place.city,
      formatRupiah(amount),
      `Rencana lewat ${method}`,
      note.trim() ? `Catatan: ${note.trim()}` : "",
      `Nomor catatan: ${code}`,
      when,
      "Tidak ada uang yang berpindah dari aplikasi ini.",
      result.bonus ? `Pengingat harian: +${NIAT_POINTS} poin. Bukan pahala.` : "Pengingat poin hari ini sudah tercatat.",
    ]
      .filter(Boolean)
      .join("\n");
    setError("");
    setCopied(false);
    setReceipt(text);
  }

  return (
    <div className="grid gap-4">
      <header>
        <h1 className="text-2xl font-semibold leading-tight">Sedekah wakaf</h1>
        <p className="mt-2 text-sm text-muted">Jurnal niat untuk panti asuhan. Seikhlasnya, lalu kamu yang mengirimnya sendiri.</p>
      </header>

      <section className="card bg-gold-soft px-4 py-4 text-sm text-ink">
        NurPray tidak memotong Dana, GoPay, OVO, ShopeePay, atau rekening bank. Tidak ada transfer otomatis. Nama panti di sini contoh jurnal, bukan nomor rekening resmi. Untuk sedekah sungguhan, kirim lewat kanal lembaga yang kamu percaya, lalu catat nominalnya di sini sebagai pengingat.
      </section>

      <form
        className="grid gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <fieldset className="grid gap-2">
          <legend className="text-sm font-semibold">Panti</legend>
          {PANTI.map((place) => (
            <label key={place.id} className={cn("card flex min-h-16 cursor-pointer items-center gap-3 px-4 py-3", pantiId === place.id && "border-jade")}>
              <input type="radio" name="panti" className="size-4 accent-jade" checked={pantiId === place.id} onChange={() => setPantiId(place.id)} />
              <span>
                <span className="block font-semibold">{place.name}</span>
                <span className="block text-sm text-muted">
                  {place.city} · {place.focus}
                </span>
              </span>
            </label>
          ))}
        </fieldset>

        <label className="grid gap-2 text-sm">
          <span className="font-semibold">Nominal seikhlasnya</span>
          <input
            className="field tabular-nums"
            inputMode="numeric"
            value={nominal}
            onChange={(event) => setNominal(event.target.value.replace(/[^\d]/g, ""))}
            aria-label="Nominal rupiah"
          />
          <span className="text-muted">{nominal ? formatRupiah(Number(nominal) || 0) : "Rp0"}</span>
          <span className="flex flex-wrap gap-2">
            {PRESETS.map((preset) => (
              <button key={preset} type="button" className="min-h-11 rounded-full border border-line bg-surface px-3 text-sm" onClick={() => setNominal(String(preset))}>
                {formatRupiah(preset)}
              </button>
            ))}
          </span>
        </label>

        <fieldset className="grid gap-2">
          <legend className="text-sm font-semibold">Rencana pembayaran</legend>
          <div className="flex flex-wrap gap-2">
            {METHODS.map((item) => (
              <button
                key={item}
                type="button"
                aria-pressed={method === item}
                onClick={() => setMethod(item)}
                className={cn(
                  "min-h-11 rounded-full border px-3 text-sm",
                  method === item ? "border-jade bg-jade text-surface" : "border-line bg-surface text-ink",
                )}
              >
                {item}
              </button>
            ))}
          </div>
        </fieldset>

        <label className="grid gap-1 text-sm">
          <span className="font-semibold">Catatan singkat</span>
          <input className="field" value={note} maxLength={80} onChange={(event) => setNote(event.target.value)} placeholder="Misalnya untuk makan anak" />
        </label>

        {error ? <p className="text-sm">{error}</p> : null}
        <Button type="submit">Simpan niat</Button>
      </form>

      {receipt ? (
        <section className="card px-4 py-4">
          <h2 className="text-lg font-semibold">Nota niat</h2>
          <pre className="mt-3 whitespace-pre-wrap font-sans text-sm">{receipt}</pre>
          <Button
            tone="line"
            className="mt-3"
            onClick={() => {
              void navigator.clipboard?.writeText(receipt).then(() => setCopied(true)).catch(() => setCopied(false));
            }}
          >
            {copied ? "Tersalin" : "Salin ringkasan"}
          </Button>
        </section>
      ) : null}

      <section className="grid gap-2">
        <h2 className="text-lg font-semibold">Riwayat di perangkat ini</h2>
        {niats.length === 0 ? <p className="text-sm text-muted">Belum ada niat tersimpan.</p> : null}
        {niats.map((item) => {
          const place = pantiById(item.pantiId);
          return (
            <article key={item.id} className="card px-4 py-3 text-sm">
              <p className="font-semibold">{place?.name ?? "Panti"}</p>
              <p className="tabular-nums">{formatRupiah(item.nominal)} · {item.method}</p>
              {item.note ? <p className="text-muted">{item.note}</p> : null}
              <p className="text-muted">{new Date(item.at).toLocaleString("id-ID")}</p>
            </article>
          );
        })}
      </section>
    </div>
  );
}

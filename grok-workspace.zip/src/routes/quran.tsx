import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SURAHS } from "@/data/surahs";

export const Route = createFileRoute("/quran")({ component: QuranPage });

function QuranPage() {
  const [query, setQuery] = useState("");
  const items = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return SURAHS;
    return SURAHS.filter((surah) =>
      `${surah.nomor} ${surah.latin} ${surah.arti} ${surah.turun}`.toLowerCase().includes(needle),
    );
  }, [query]);

  return (
    <div className="grid gap-4">
      <header>
        <h1 className="text-2xl font-semibold leading-tight">Mushaf</h1>
        <p className="mt-2 text-sm text-muted">
          Arab, latin, dan terjemah bahasa Indonesia. Teks serta murottal dimuat dari equran.id. Mushaf ini bebas dibaca.
        </p>
      </header>
      <label className="grid gap-1 text-sm">
        <span className="font-semibold">Cari surat</span>
        <input
          className="field"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Nama, arti, atau nomor"
          inputMode="search"
        />
      </label>
      <p className="text-sm text-muted">{items.length} surat</p>
      {items.length === 0 ? <p className="text-sm">Tidak ada surat dengan kata itu.</p> : null}
      <ul className="grid gap-2">
        {items.map((surah) => (
          <li key={surah.nomor}>
            <Link
              to="/quran/$nomor"
              params={{ nomor: String(surah.nomor) }}
              className="card flex min-h-16 items-center gap-3 px-3 py-3"
            >
              <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-jade-soft text-sm font-semibold text-jade">
                {surah.nomor}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block font-semibold">{surah.latin}</span>
                <span className="block text-sm text-muted">
                  {surah.arti} · {surah.ayat} ayat · {surah.turun}
                </span>
              </span>
              <span dir="rtl" lang="ar" className="shrink-0 font-arab text-xl">
                {surah.arab}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

import { createFileRoute, Link } from "@tanstack/react-router";
import { Bookmark, Pause, Play } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/button";
import { cn } from "@/lib/cn";
import { FREE_MARKS } from "@/lib/mission";
import { fetchSurah, plainText, QARI, type SurahDetail } from "@/lib/quran-api";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/quran/$nomor")({ component: SurahPage });

const ARAB = ["text-2xl", "text-3xl", "text-4xl"] as const;
const BODY = ["text-sm", "text-base", "text-lg"] as const;

function SurahPage() {
  const { nomor } = Route.useParams();
  const n = Number(nomor);
  const quranKu = useApp((s) => s.quranKu);
  const qari = useApp((s) => s.qari);
  const setQari = useApp((s) => s.setQari);
  const night = useApp((s) => s.night);
  const setNight = useApp((s) => s.setNight);
  const arabSize = useApp((s) => s.arabSize);
  const setArabSize = useApp((s) => s.setArabSize);
  const bookmarks = useApp((s) => s.bookmarks);
  const toggleBookmark = useApp((s) => s.toggleBookmark);
  const [surah, setSurah] = useState<SurahDetail | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [openDesc, setOpenDesc] = useState(false);
  const [markNote, setMarkNote] = useState("");
  const [playing, setPlaying] = useState<string | null>(null);
  const [latinOn, setLatinOn] = useState(true);
  const audio = useRef<HTMLAudioElement | null>(null);
  const dark = quranKu && night;
  const voice = quranKu ? qari : "05";

  useEffect(() => {
    if (!Number.isInteger(n) || n < 1 || n > 114) {
      setLoading(false);
      setError("Surat tidak dikenal.");
      return;
    }
    const ctrl = new AbortController();
    setLoading(true);
    setError("");
    fetchSurah(n, ctrl.signal)
      .then((data) => {
        setSurah(data);
        setLoading(false);
      })
      .catch((err: unknown) => {
        if (ctrl.signal.aborted) return;
        setLoading(false);
        setError(err instanceof Error ? err.message : "Surat gagal dimuat.");
      });
    return () => ctrl.abort();
  }, [n]);

  useEffect(() => {
    return () => {
      audio.current?.pause();
    };
  }, []);

  useEffect(() => {
    if (!surah || !window.location.hash) return;
    document.getElementById(window.location.hash.slice(1))?.scrollIntoView({ block: "center" });
  }, [surah]);

  function play(url: string) {
    if (!url) return;
    const node = audio.current ?? new Audio();
    audio.current = node;
    if (playing === url) {
      node.pause();
      setPlaying(null);
      return;
    }
    node.src = url;
    node.onended = () => setPlaying(null);
    void node.play().then(() => setPlaying(url)).catch(() => setPlaying(null));
  }

  if (!Number.isInteger(n) || n < 1 || n > 114) {
    return <p>Surat tidak dikenal.</p>;
  }

  return (
    <div className="grid gap-4">
      <Link to="/quran" className="text-sm font-semibold text-jade">
        Semua surat
      </Link>
      {loading ? (
        <div className="grid gap-2" aria-hidden="true">
          <div className="h-8 w-40 rounded-full bg-line motion-safe:animate-pulse" />
          <div className="h-24 rounded-card bg-line motion-safe:animate-pulse" />
          <div className="h-24 rounded-card bg-line motion-safe:animate-pulse" />
        </div>
      ) : null}
      {error ? (
        <div className="card px-4 py-4">
          <p>{error}</p>
          <Button className="mt-3" onClick={() => window.location.reload()}>
            Coba lagi
          </Button>
        </div>
      ) : null}
      {surah ? (
        <>
          <header className={cn("card px-5 py-5", dark && "border-gold-soft bg-ink text-surface")}>
            <p className="text-sm text-jade">{surah.tempatTurun}</p>
            <h1 className="mt-1 text-2xl font-semibold leading-tight">{surah.namaLatin}</h1>
            <p className={cn("font-arab text-3xl leading-loose", dark ? "text-gold-soft" : "text-ink")} dir="rtl" lang="ar">
              {surah.nama}
            </p>
            <p className={cn("text-sm", dark ? "text-gold-soft" : "text-muted")}>
              {surah.arti} · {surah.jumlahAyat} ayat
            </p>
            <p className={cn("mt-3 text-sm", !openDesc && "line-clamp-4", dark ? "text-gold-soft" : "text-muted")}>
              {plainText(surah.deskripsi)}
            </p>
            <button type="button" className="mt-2 min-h-11 text-sm font-semibold text-jade" onClick={() => setOpenDesc((v) => !v)}>
              {openDesc ? "Ringkas" : "Selengkapnya"}
            </button>
          </header>

          <div className="flex flex-wrap gap-2">
            <Button tone={latinOn ? "soft" : "line"} onClick={() => setLatinOn((v) => !v)}>
              Latin
            </Button>
            {([0, 1, 2] as const).map((size) => (
              <Button key={size} tone={arabSize === size ? "soft" : "line"} onClick={() => setArabSize(size)} aria-pressed={arabSize === size}>
                {size === 0 ? "A" : size === 1 ? "A+" : "A++"}
              </Button>
            ))}
            <Button tone={dark ? "gold" : "line"} onClick={() => (quranKu ? setNight(!night) : setMarkNote("Mode malam ada di QuranKu."))}>
              Mode malam
            </Button>
          </div>

          <label className="grid gap-1 text-sm">
            <span className="font-semibold">Qari</span>
            <select
              className="field"
              value={voice}
              onChange={(e) => {
                if (!quranKu && e.target.value !== "05") {
                  setMarkNote("Qari lain terbuka bersama QuranKu. Misyari tetap bisa didengar.");
                  return;
                }
                setQari(e.target.value);
              }}
            >
              {QARI.map((item) => (
                <option key={item.id} value={item.id} disabled={!quranKu && item.id !== "05"}>
                  {item.name}
                  {!quranKu && item.id !== "05" ? " · QuranKu" : ""}
                </option>
              ))}
            </select>
          </label>

          {surah.audioFull?.[voice] ? (
            <Button tone="line" onClick={() => play(surah.audioFull[voice])}>
              {playing === surah.audioFull[voice] ? <Pause className="size-4" /> : <Play className="size-4" />}
              {playing === surah.audioFull[voice] ? "Jeda surat" : "Putar surat"}
            </Button>
          ) : null}

          {markNote ? <p className="text-sm">{markNote}</p> : null}

          <ol className="grid gap-3">
            {surah.ayat.map((ayat) => {
              const saved = bookmarks.some((b) => b.surah === surah.nomor && b.ayah === ayat.nomorAyat);
              const src = ayat.audio?.[voice];
              return (
                <li key={ayat.nomorAyat} id={`ayat-${ayat.nomorAyat}`} className={cn("card px-4 py-4", dark && "border-gold-soft bg-ink text-surface")}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex size-8 items-center justify-center rounded-full bg-jade-soft text-sm font-semibold text-jade">
                      {ayat.nomorAyat}
                    </span>
                    <span className="flex gap-1">
                      {src ? (
                        <button type="button" className="flex size-11 items-center justify-center" onClick={() => play(src)} aria-label={`Putar ayat ${ayat.nomorAyat}`}>
                          {playing === src ? <Pause className="size-4" /> : <Play className="size-4" />}
                        </button>
                      ) : null}
                      <button
                        type="button"
                        className="flex size-11 items-center justify-center"
                        aria-pressed={saved}
                        aria-label={saved ? "Hapus penanda" : "Tandai ayat"}
                        onClick={() => {
                          const status = toggleBookmark(surah.nomor, ayat.nomorAyat);
                          setMarkNote(
                            status === "full"
                              ? `Penanda gratis penuh (${FREE_MARKS}). QuranKu menyimpan tanpa batas.`
                              : status === "added"
                                ? "Ayat ditandai di jejakmu."
                                : "",
                          );
                        }}
                      >
                        <Bookmark className={cn("size-4", saved && "fill-jade text-jade")} />
                      </button>
                    </span>
                  </div>
                  <p dir="rtl" lang="ar" className={cn("mt-2 text-right font-arab leading-loose", ARAB[arabSize], dark ? "text-surface" : "text-ink")}>
                    {ayat.teksArab}
                  </p>
                  {latinOn ? <p className={cn("mt-2", BODY[arabSize], dark ? "text-gold-soft" : "text-muted")}>{ayat.teksLatin}</p> : null}
                  <p className={cn("mt-2", BODY[arabSize], dark ? "text-gold-soft" : "text-ink")}>{plainText(ayat.teksIndonesia)}</p>
                </li>
              );
            })}
          </ol>
        </>
      ) : null}
    </div>
  );
}

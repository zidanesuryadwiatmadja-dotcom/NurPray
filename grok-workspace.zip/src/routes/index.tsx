import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Gift, HandHeart, Library } from "lucide-react";
import { Button } from "@/components/button";
import { KincirMark } from "@/components/kincir-mark";
import { PrayerList } from "@/components/prayer-list";
import { formatCxp, formatPoin } from "@/lib/format";
import { motif } from "@/lib/motivations";
import {
  BONUS_CXP,
  BONUS_POINTS,
  completeDays,
  inWindow,
  phaseOf,
  PRAYER_CXP,
  PRAYER_POINTS,
} from "@/lib/mission";
import { useApp } from "@/lib/store";
import { useDailyNumber, useGreeting, useToday } from "@/lib/use-clock";
import { usePrayerTimes } from "@/lib/use-prayer-times";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const name = useApp((s) => s.name);
  const city = useApp((s) => s.city);
  const points = useApp((s) => s.points);
  const cxp = useApp((s) => s.cxp);
  const start = useApp((s) => s.missionStart);
  const logs = useApp((s) => s.logs);
  const cycles = useApp((s) => s.cycles);
  const quranKu = useApp((s) => s.quranKu);
  const today = useToday();
  const greet = useGreeting(name);
  const daily = motif(useDailyNumber());
  const clock = usePrayerTimes(city);
  const phase = phaseOf(start, logs, today);
  const utuh = completeDays(start, logs);
  const open = inWindow(start, today);

  return (
    <div className="grid gap-4">
      <section className="card px-5 py-5">
        <p className="text-center font-arab text-2xl leading-loose text-ink" lang="ar" dir="rtl">
          بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
        </p>
        <h1 className="mt-1 text-center text-2xl font-semibold leading-tight">{greet}</h1>
        <p className="mt-2 text-center text-sm text-muted">
          {clock.hijri ? `${clock.hijri} · ` : ""}
          {city}
          {quranKu ? " · QuranKu aktif" : ""}
          {cycles > 0 ? ` · ${cycles} misi tuntas` : ""}
        </p>
        <p className="mt-3 text-center">
          <Link to="/jejak" className="text-sm font-semibold text-jade">
            Nama, kota, dan ayat tersimpan
          </Link>
        </p>
      </section>

      <section className="grid grid-cols-2 gap-3">
        <Link to="/hadiah" className="card min-h-20 px-4 py-3">
          <span className="block text-xs text-muted">Poin</span>
          <span className="mt-1 block text-xl font-semibold tabular-nums">{formatPoin(points)}</span>
        </Link>
        <Link to="/hadiah" className="card min-h-20 px-4 py-3">
          <span className="block text-xs text-muted">CXP</span>
          <span className="mt-1 block text-xl font-semibold tabular-nums">{formatCxp(cxp)}</span>
        </Link>
      </section>

      <section className="card px-5 py-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold">Misi 14 hari</h2>
            <p className="mt-1 text-sm text-muted">
              Lima waktu tanpa bolong. Setiap catatan {formatPoin(PRAYER_POINTS)} poin dan {formatCxp(PRAYER_CXP)} CXP.
              Penuh 14 hari: {formatPoin(BONUS_POINTS)} poin dan {formatCxp(BONUS_CXP)} CXP.
            </p>
          </div>
          <span className="text-sm font-semibold tabular-nums text-jade">{utuh}/14</span>
        </div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-line" aria-hidden="true">
          <div className="h-full bg-jade" style={{ width: `${(utuh / 14) * 100}%` }} />
        </div>
        <p className="mt-3 text-sm">
          {!today && "Menyetel tanggal perangkat…"}
          {today && phase === "idle" && "Belum dimulai. Catatan baru terhitung setelah misi dibuka."}
          {today && phase === "active" && start && `Hari ke-${missionDay(start, today)} sedang berjalan.`}
          {today && phase === "bolong" && "Rantai terputus. Poin yang sudah masuk tetap ada. Kamu bisa mulai siklus baru."}
          {today && phase === "expired" && "Jendela 14 hari sudah lewat sebelum lengkap."}
          {today && phase === "complete" && "Misi penuh. Bonus sudah masuk ke poin dan CXP."}
        </p>
        <Button asChild tone="jade" className="mt-4">
          <Link to="/misi">{phase === "idle" ? "Buka misi" : "Lihat papan misi"}</Link>
        </Button>
      </section>

      <section>
        <div className="mb-2 flex items-end justify-between gap-3">
          <h2 className="text-lg font-semibold">Hari ini</h2>
          <p className="text-xs text-muted">Perkiraan Kemenag</p>
        </div>
        {!open && phase !== "active" ? (
          <p className="mb-2 text-sm text-muted">Jadwal ditampilkan. Centang aktif setelah misi hari ini dibuka.</p>
        ) : null}
        <PrayerList today={today} />
      </section>

      <section className="card border-l-4 border-l-jade px-5 py-5">
        <p className="text-xs font-semibold tracking-wide text-jade">Renungan {daily.n}</p>
        <h2 className="mt-1 text-lg font-semibold">{daily.cat}</h2>
        <p className="mt-2">{daily.lead}</p>
        <Button asChild tone="line" className="mt-4">
          <Link to="/motivasi">Baca 777 renungan</Link>
        </Button>
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        <Link to="/kincir" className="card flex min-h-24 items-center gap-3 px-4 py-4">
          <KincirMark className="size-12 shrink-0" />
          <span>
            <span className="block font-semibold">Kincir ayat</span>
            <span className="block text-sm text-muted">Putar, lalu baca ayat yang terbuka.</span>
          </span>
        </Link>
        <Link to="/quran" className="card flex min-h-24 items-center gap-3 px-4 py-4">
          <BookOpen className="size-6 shrink-0 text-jade" aria-hidden="true" />
          <span>
            <span className="block font-semibold">Mushaf QuranKu</span>
            <span className="block text-sm text-muted">114 surat, latin, terjemah, dan murottal.</span>
          </span>
        </Link>
        <Link to="/sedekah" className="card flex min-h-24 items-center gap-3 px-4 py-4">
          <HandHeart className="size-6 shrink-0 text-jade" aria-hidden="true" />
          <span>
            <span className="block font-semibold">Sedekah wakaf</span>
            <span className="block text-sm text-muted">Jurnal niat untuk panti asuhan. Tidak memotong saldo.</span>
          </span>
        </Link>
        <Link to="/hadiah" className="card flex min-h-24 items-center gap-3 px-4 py-4">
          <Gift className="size-6 shrink-0 text-gold" aria-hidden="true" />
          <span>
            <span className="block font-semibold">Tukar QuranKu</span>
            <span className="block text-sm text-muted">Minimal 50.000 poin dan 677.000,0 CXP.</span>
          </span>
        </Link>
        <Link to="/motivasi" className="card flex min-h-24 items-center gap-3 px-4 py-4 sm:col-span-2">
          <Library className="size-6 shrink-0 text-jade" aria-hidden="true" />
          <span>
            <span className="block font-semibold">777 motivasi harian</span>
            <span className="block text-sm text-muted">Sholat, ngaji, sedekah, dakwah, akhlak, dan jalan pulang.</span>
          </span>
        </Link>
      </section>
    </div>
  );
}

function missionDay(start: string, today: string) {
  const [ys, ms, ds] = start.split("-").map(Number);
  const [yt, mt, dt] = today.split("-").map(Number);
  const a = new Date(ys, ms - 1, ds).getTime();
  const b = new Date(yt, mt - 1, dt).getTime();
  const diff = Math.round((b - a) / 86_400_000);
  return Math.min(14, Math.max(1, diff + 1));
}

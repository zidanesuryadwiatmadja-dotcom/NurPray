import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/button";
import { CITIES } from "@/lib/charity";
import { motif } from "@/lib/motivations";
import { surahMeta } from "@/lib/quran-api";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/jejak")({ component: JejakPage });

function JejakPage() {
  const name = useApp((s) => s.name);
  const city = useApp((s) => s.city);
  const setName = useApp((s) => s.setName);
  const setCity = useApp((s) => s.setCity);
  const bookmarks = useApp((s) => s.bookmarks);
  const favs = useApp((s) => s.favs);
  const quranKu = useApp((s) => s.quranKu);
  const resetAll = useApp((s) => s.resetAll);
  const [ask, setAsk] = useState(false);

  return (
    <div className="grid gap-4">
      <header>
        <h1 className="text-2xl font-semibold leading-tight">Jejak di perangkat</h1>
        <p className="mt-2 text-sm text-muted">
          Nama, kota, penanda, dan poin tersimpan hanya di peramban ini. {quranKu ? "QuranKu aktif." : "QuranKu belum ditukar."}
        </p>
      </header>

      <label className="grid gap-1 text-sm">
        <span className="font-semibold">Nama panggilan</span>
        <input className="field" value={name} maxLength={24} onChange={(event) => setName(event.target.value)} placeholder="Nama panggilan" />
      </label>

      <label className="grid gap-1 text-sm">
        <span className="font-semibold">Kota waktu sholat</span>
        <select className="field" value={city} onChange={(event) => setCity(event.target.value)}>
          {CITIES.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
      </label>

      <section className="grid gap-2">
        <h2 className="text-lg font-semibold">Ayat tertandai</h2>
        {bookmarks.length === 0 ? <p className="text-sm text-muted">Belum ada. Tandai dari dalam surat.</p> : null}
        {bookmarks.map((mark) => {
          const meta = surahMeta(mark.surah);
          return (
            <Link
              key={`${mark.surah}-${mark.ayah}`}
              to="/quran/$nomor"
              params={{ nomor: String(mark.surah) }}
              hash={`ayat-${mark.ayah}`}
              className="card min-h-14 px-4 py-3 text-sm"
            >
              <span className="font-semibold">{meta?.latin ?? `Surat ${mark.surah}`}</span>
              <span className="text-muted"> · ayat {mark.ayah}</span>
            </Link>
          );
        })}
      </section>

      <section className="grid gap-2">
        <h2 className="text-lg font-semibold">Renungan tersimpan</h2>
        {favs.length === 0 ? <p className="text-sm text-muted">Belum ada favorit.</p> : null}
        {favs.map((n) => {
          const item = motif(n);
          return (
            <Link key={n} to="/motivasi" hash={`m-${n}`} className="card min-h-14 px-4 py-3 text-sm">
              <span className="font-semibold">
                {item.n} · {item.cat}
              </span>
              <span className="mt-1 block text-muted">{item.lead}</span>
            </Link>
          );
        })}
      </section>

      <section className="card px-4 py-4">
        <h2 className="text-lg font-semibold">Hapus data</h2>
        <p className="mt-2 text-sm text-muted">Poin, misi, niat, dan penanda di perangkat ini akan hilang.</p>
        {ask ? (
          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              onClick={() => {
                resetAll();
                setAsk(false);
              }}
            >
              Ya, hapus
            </Button>
            <Button tone="line" onClick={() => setAsk(false)}>
              Batal
            </Button>
          </div>
        ) : (
          <Button tone="line" className="mt-3" onClick={() => setAsk(true)}>
            Hapus data perangkat
          </Button>
        )}
      </section>
    </div>
  );
}

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/button";
import { KincirMark } from "@/components/kincir-mark";
import { FREE_SPINS } from "@/lib/mission";
import { fetchSurah, randomPointer, type Ayat, type SurahDetail } from "@/lib/quran-api";
import { useApp } from "@/lib/store";
import { useReducedMotion } from "@/lib/use-clock";

export const Route = createFileRoute("/kincir")({ component: KincirPage });

function KincirPage() {
  const quranKu = useApp((s) => s.quranKu);
  const recordSpin = useApp((s) => s.recordSpin);
  const spinsLeft = useApp((s) => s.spinsLeft());
  const reduced = useReducedMotion();
  const [deg, setDeg] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ surah: SurahDetail; ayat: Ayat } | null>(null);
  const live = useRef(true);
  const lock = useRef(false);
  useEffect(() => {
    live.current = true;
    return () => {
      live.current = false;
    };
  }, []);

  async function spin() {
    if (lock.current || spinning) return;
    if (!quranKu && spinsLeft <= 0) {
      setError("Putaran gratis hari ini habis. QuranKu membuka kincir tanpa batas.");
      return;
    }
    lock.current = true;
    setError("");
    setSpinning(true);
    const pointer = randomPointer();
    setDeg((value) => value + 1800 + Math.floor(Math.random() * 360));
    const wait = reduced ? 200 : 2800;
    const ctrl = new AbortController();
    const timer = window.setTimeout(() => ctrl.abort(), 12000);
    try {
      const [surah] = await Promise.all([
        fetchSurah(pointer.nomor, ctrl.signal),
        new Promise((resolve) => window.setTimeout(resolve, wait)),
      ]);
      const ayat = surah.ayat.find((item) => item.nomorAyat === pointer.ayah) ?? surah.ayat[0];
      if (!ayat) throw new Error("Ayat kosong");
      if (!recordSpin()) {
        setError("Putaran gratis hari ini habis.");
        return;
      }
      setResult({ surah, ayat });
    } catch {
      setError("Ayat belum terunduh. Periksa sambungan, lalu putar lagi. Putaran ini tidak terpakai.");
    } finally {
      window.clearTimeout(timer);
      lock.current = false;
      if (live.current) setSpinning(false);
    }
  }

  return (
    <div className="grid gap-5">
      <header>
        <h1 className="text-2xl font-semibold leading-tight">Kincir ayat</h1>
        <p className="mt-2 text-sm text-muted">
          Putar roset ini untuk membuka satu ayat secara acak. Bukan undian hadiah — ini cara yang tenang untuk bertemu ayat.
        </p>
      </header>

      <div className="card flex flex-col items-center px-4 py-8">
        <div
          className="size-64"
          style={{
            transform: `rotate(${deg}deg)`,
            transitionProperty: "transform",
            transitionDuration: reduced ? "1ms" : "2800ms",
            transitionTimingFunction: "cubic-bezier(0.12, 0.7, 0.12, 1)",
          }}
        >
          <KincirMark className="size-full" />
        </div>
        <Button className="mt-6" onClick={() => void spin()} disabled={spinning}>
          {spinning ? "Berputar…" : "Putar kincir"}
        </Button>
        <p className="mt-3 text-center text-sm text-muted">
          {quranKu ? "QuranKu aktif · putaran tanpa batas harian." : `Putaran gratis hari ini: ${spinsLeft} dari ${FREE_SPINS}.`}
        </p>
      </div>

      {error ? <p className="text-sm text-ink">{error}</p> : null}

      {result ? (
        <article className="card px-5 py-5">
          <p className="text-sm font-semibold text-jade">
            {result.surah.namaLatin} · ayat {result.ayat.nomorAyat}
          </p>
          <p className="mt-1 text-sm text-muted">{result.surah.arti}</p>
          <p dir="rtl" lang="ar" className="mt-4 text-right font-arab text-3xl leading-loose">
            {result.ayat.teksArab}
          </p>
          <p className="mt-3 text-sm text-muted">{result.ayat.teksLatin}</p>
          <p className="mt-3">{result.ayat.teksIndonesia}</p>
          <Button asChild tone="line" className="mt-4">
            <Link to="/quran/$nomor" params={{ nomor: String(result.surah.nomor) }} hash={`ayat-${result.ayat.nomorAyat}`}>
              Buka di mushaf
            </Link>
          </Button>
        </article>
      ) : (
        <p className="text-sm text-muted">Hasil ayat akan muncul di sini setelah kincir berhenti.</p>
      )}

      {!quranKu ? (
        <p className="text-sm">
          Ingin memutar seharian?{" "}
          <Link to="/hadiah" className="font-semibold text-jade">
            Tukar QuranKu
          </Link>{" "}
          setelah misi 14 hari penuh.
        </p>
      ) : null}
    </div>
  );
}

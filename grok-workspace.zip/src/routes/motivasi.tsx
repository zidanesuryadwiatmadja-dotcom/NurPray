import { createFileRoute } from "@tanstack/react-router";
import { Bookmark } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/button";
import { cn } from "@/lib/cn";
import { FREE_FAVS } from "@/lib/mission";
import { CATS, motif, MOTIF_READY, searchMotifs, type Cat } from "@/lib/motivations";
import { useApp } from "@/lib/store";
import { useDailyNumber } from "@/lib/use-clock";

export const Route = createFileRoute("/motivasi")({ component: MotivasiPage });

function MotivasiPage() {
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<Cat | "Semua">("Semua");
  const [count, setCount] = useState(12);
  const [note, setNote] = useState("");
  const [pin, setPin] = useState<number | null>(null);
  const daily = useDailyNumber();
  const favs = useApp((s) => s.favs);
  const toggleFav = useApp((s) => s.toggleFav);
  const items = useMemo(() => searchMotifs(query, cat), [query, cat]);
  const pinned = pin && pin >= 1 && pin <= 777 ? motif(pin) : null;

  useEffect(() => {
    const match = window.location.hash.match(/^#m-(\d+)$/);
    if (!match) return;
    const n = Number(match[1]);
    if (n >= 1 && n <= 777) setPin(n);
  }, []);

  return (
    <div className="grid gap-4">
      <header>
        <h1 className="text-2xl font-semibold leading-tight">777 renungan</h1>
        <p className="mt-2 text-sm text-muted">
          Bacaan harian tentang sholat, ngaji, sedekah, dakwah, dan akhlak. Ini bukan kumpulan hadits. Jika ada isyarat ayat, itu makna ringkas, bukan tafsir.
        </p>
        {!MOTIF_READY ? <p className="mt-2 text-sm">Daftar renungan belum utuh.</p> : null}
      </header>

      <DailyCard n={daily} saved={favs.includes(daily)} onSave={() => save(daily, toggleFav, setNote)} />

      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const n = Number(query);
          if (Number.isInteger(n) && n >= 1 && n <= 777) {
            setPin(n);
            setQuery("");
          }
        }}
      >
        <input
          className="field"
          value={query}
          onChange={(event) => {
            setQuery(event.target.value);
            setCount(12);
          }}
          placeholder="Cari kata atau nomor 1–777"
          inputMode="search"
          aria-label="Cari renungan"
        />
      </form>

      <div className="flex gap-2 overflow-x-auto pb-1">
        <Chip on={cat === "Semua"} onClick={() => { setCat("Semua"); setCount(12); }}>
          Semua
        </Chip>
        {CATS.map((item) => (
          <Chip
            key={item}
            on={cat === item}
            onClick={() => {
              setCat(item);
              setCount(12);
            }}
          >
            {item}
          </Chip>
        ))}
      </div>

      {note ? <p className="text-sm">{note}</p> : null}
      {pinned ? (
        <div className="grid gap-2">
          <MotifCard item={pinned} saved={favs.includes(pinned.n)} onSave={() => save(pinned.n, toggleFav, setNote)} />
          <Button tone="line" onClick={() => setPin(null)}>
            Tutup nomor {pinned.n}
          </Button>
        </div>
      ) : null}

      <p className="text-sm text-muted">{items.length} renungan</p>
      <div className="grid gap-3">
        {items.slice(0, count).map((item) => (
          <MotifCard key={item.n} item={item} saved={favs.includes(item.n)} onSave={() => save(item.n, toggleFav, setNote)} />
        ))}
      </div>
      {count < items.length ? (
        <Button tone="line" onClick={() => setCount((value) => value + 12)}>
          Muat lagi
        </Button>
      ) : null}
    </div>
  );
}

function save(n: number, toggle: (n: number) => "added" | "removed" | "full", setNote: (value: string) => void) {
  const status = toggle(n);
  setNote(
    status === "full"
      ? `Favorit gratis penuh (${FREE_FAVS}). QuranKu menyimpan tanpa batas.`
      : status === "added"
        ? `Renungan ${n} disimpan.`
        : `Renungan ${n} dilepas.`,
  );
}

function DailyCard({ n, saved, onSave }: { n: number; saved: boolean; onSave: () => void }) {
  const item = motif(n);
  return (
    <section className="card border-l-4 border-l-jade px-4 py-4">
      <p className="text-xs font-semibold tracking-wide text-jade">Hari ini · nomor {item.n}</p>
      <MotifBody item={item} saved={saved} onSave={onSave} />
    </section>
  );
}

function MotifCard({
  item,
  saved,
  onSave,
}: {
  item: ReturnType<typeof motif>;
  saved: boolean;
  onSave: () => void;
}) {
  return (
    <article id={`m-${item.n}`} className="card px-4 py-4">
      <MotifBody item={item} saved={saved} onSave={onSave} />
    </article>
  );
}

function MotifBody({
  item,
  saved,
  onSave,
}: {
  item: ReturnType<typeof motif>;
  saved: boolean;
  onSave: () => void;
}) {
  return (
    <>
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm font-semibold text-muted">
          {item.n} · {item.cat}
        </p>
        <button type="button" className="flex size-11 shrink-0 items-center justify-center" onClick={onSave} aria-pressed={saved} aria-label="Simpan renungan">
          <Bookmark className={cn("size-4", saved && "fill-jade text-jade")} />
        </button>
      </div>
      <p className="text-lg font-semibold leading-snug">{item.lead}</p>
      <p className="mt-2 text-sm">{item.support}</p>
      <p className="mt-3 border-t border-line pt-3 text-sm">
        <span className="font-semibold">Amal kecil. </span>
        {item.amal}
      </p>
    </>
  );
}

function Chip({ children, on, onClick }: { children: string; on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={cn(
        "min-h-11 shrink-0 rounded-full border px-3 text-sm",
        on ? "border-jade bg-jade text-surface" : "border-line bg-surface text-ink",
      )}
    >
      {children}
    </button>
  );
}

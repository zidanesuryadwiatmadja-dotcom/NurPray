import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/button";
import { PrayerList } from "@/components/prayer-list";
import { CITIES } from "@/lib/charity";
import { cn } from "@/lib/cn";
import { missionDates, prettyDate } from "@/lib/dates";
import { formatCxp, formatPoin } from "@/lib/format";
import {
  BONUS_CXP,
  BONUS_POINTS,
  phaseOf,
  PRAYER_CXP,
  PRAYER_POINTS,
  prayerCount,
  SHOP_CXP,
  SHOP_POINTS,
} from "@/lib/mission";
import { useApp } from "@/lib/store";
import { useToday } from "@/lib/use-clock";

export const Route = createFileRoute("/misi")({ component: MisiPage });

function MisiPage() {
  const start = useApp((s) => s.missionStart);
  const logs = useApp((s) => s.logs);
  const city = useApp((s) => s.city);
  const setCity = useApp((s) => s.setCity);
  const begin = useApp((s) => s.startMission);
  const today = useToday();
  const phase = phaseOf(start, logs, today);
  const [ask, setAsk] = useState(false);
  const days = start ? missionDates(start) : [];

  return (
    <div className="grid gap-4">
      <header>
        <h1 className="text-2xl font-semibold leading-tight">Misi sholat 14 hari</h1>
        <p className="mt-2 text-sm text-muted">
          Catat Subuh, Dzuhur, Ashar, Maghrib, dan Isya pada hari yang sama. Satu hari yang lewat tanpa lima waktu memutus rantai. Bonus hanya untuk siklus yang utuh.
        </p>
      </header>

      <section className="card grid gap-3 px-4 py-4 text-sm">
        <p>Setiap sholat yang dicatat: {formatPoin(PRAYER_POINTS)} poin dan {formatCxp(PRAYER_CXP)} CXP.</p>
        <p>Siklus penuh tanpa bolong: {formatPoin(BONUS_POINTS)} poin dan {formatCxp(BONUS_CXP)} CXP.</p>
        <p>QuranKu ditukar minimal {formatPoin(SHOP_POINTS)} poin dan {formatCxp(SHOP_CXP)} CXP.</p>
        <p className="text-muted">Ketuk hanya setelah sholat benar-benar dikerjakan. Catatan hari itu tidak bisa dibatalkan, supaya poin tidak diputar ulang.</p>
      </section>

      <label className="grid gap-1 text-sm">
        <span className="font-semibold">Kota untuk perkiraan waktu</span>
        <select className="field" value={city} onChange={(e) => setCity(e.target.value)}>
          {CITIES.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
        <span className="text-muted">Perkiraan metode Kemenag. Cocokkan dengan masjid atau jadwal setempatmu.</span>
      </label>

      {!today ? <p className="text-sm text-muted">Menyetel tanggal perangkat…</p> : null}
      {today && phase === "idle" ? <Button onClick={() => begin()}>Mulai dari hari ini</Button> : null}
      {today && (phase === "bolong" || phase === "expired" || phase === "complete") ? (
        <section className="card px-4 py-4">
          <p className="text-sm">
            {phase === "bolong" && "Ada hari yang belum utuh. Poin sholat yang sudah masuk tidak ditarik."}
            {phase === "expired" && "14 hari sudah lewat sebelum lengkap. Kamu bisa membuka siklus baru."}
            {phase === "complete" && "Siklus ini tuntas dan bonusnya sudah masuk. Siklus berikutnya boleh dimulai dari hari ini."}
          </p>
          {ask ? (
            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                onClick={() => {
                  begin();
                  setAsk(false);
                }}
              >
                Ya, mulai hari ini
              </Button>
              <Button tone="line" onClick={() => setAsk(false)}>
                Batal
              </Button>
            </div>
          ) : (
            <Button className="mt-3" tone="line" onClick={() => setAsk(true)}>
              Mulai siklus baru
            </Button>
          )}
        </section>
      ) : null}

      {start && today ? (
        <section>
          <h2 className="mb-2 text-lg font-semibold">Papan 14 hari</h2>
          <ol className="grid max-w-lg grid-cols-7 gap-2">
            {days.map((date) => {
              const count = prayerCount(logs, date);
              const future = date > today;
              const miss = date < today && count < 5;
              const done = count >= 5;
              const isToday = date === today;
              return (
                <li
                  key={date}
                  className={cn(
                    "card flex min-h-16 flex-col items-center justify-center px-1 py-2 text-center",
                    done && "border-jade bg-jade-soft",
                    isToday && "border-jade",
                  )}
                >
                  <span className="text-sm font-semibold tabular-nums">{prettyDate(date).split(" ")[0]}</span>
                  <span className="text-xs text-muted">
                    {future ? "Nanti" : done ? "Utuh" : miss ? "Bolong" : `${count}/5`}
                  </span>
                </li>
              );
            })}
          </ol>
        </section>
      ) : null}

      <section>
        <h2 className="mb-2 text-lg font-semibold">Catatan hari ini</h2>
        <PrayerList today={today} />
      </section>

      <p className="text-sm text-muted">
        Hadiahnya dibuka di dalam NurPray, bukan berkas unduhan.{" "}
        <Link to="/hadiah" className="font-semibold text-jade">
          Lihat QuranKu
        </Link>
      </p>
    </div>
  );
}

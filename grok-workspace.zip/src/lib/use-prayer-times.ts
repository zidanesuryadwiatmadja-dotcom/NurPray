import { useEffect, useState } from "react";

export type PrayerClock = {
  times: Record<string, string> | null;
  hijri: string | null;
  error: string | null;
};

const HIJRI = [
  "",
  "Muharram",
  "Safar",
  "Rabiul Awal",
  "Rabiul Akhir",
  "Jumadil Awal",
  "Jumadil Akhir",
  "Rajab",
  "Syaban",
  "Ramadan",
  "Syawal",
  "Zulkaidah",
  "Zulhijah",
];

const cache = new Map<string, PrayerClock>();

export function usePrayerTimes(city: string) {
  const [clock, setClock] = useState<PrayerClock>({ times: null, hijri: null, error: null });

  useEffect(() => {
    const now = new Date();
    const dd = String(now.getDate()).padStart(2, "0");
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const key = `${now.getFullYear()}-${mm}-${dd}-${city}`;
    const hit = cache.get(key);
    if (hit) {
      setClock(hit);
      return;
    }
    let cancel = false;
    const url = `https://api.aladhan.com/v1/timingsByCity/${dd}-${mm}-${now.getFullYear()}?city=${encodeURIComponent(city)}&country=Indonesia&method=20`;
    fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error("jadwal");
        return res.json();
      })
      .then((json: { data?: { timings?: Record<string, string>; date?: { hijri?: { day?: string; month?: { number?: number }; year?: string } } } }) => {
        if (cancel) return;
        const timings = json.data?.timings;
        if (!timings) throw new Error("kosong");
        const h = json.data?.date?.hijri;
        const month = HIJRI[h?.month?.number ?? 0] || "";
        const hijri = h?.day && month ? `${h.day} ${month} ${h.year} H` : null;
        const next = { times: timings, hijri, error: null };
        cache.set(key, next);
        setClock(next);
      })
      .catch(() => {
        if (!cancel) setClock({ times: null, hijri: null, error: "Jadwal kota ini belum termuat." });
      });
    return () => {
      cancel = true;
    };
  }, [city]);

  return clock;
}

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { missionDates, todayKey } from "@/lib/dates";
import {
  BONUS_CXP,
  BONUS_POINTS,
  FREE_FAVS,
  FREE_MARKS,
  FREE_SPINS,
  NIAT_POINTS,
  PRAYER_CXP,
  PRAYER_POINTS,
  SHOP_CXP,
  SHOP_POINTS,
  inWindow,
  phaseOf,
  prayerCount,
  type Logs,
  type PrayerId,
} from "@/lib/mission";

export type Niat = {
  id: string;
  at: string;
  pantiId: string;
  nominal: number;
  method: string;
  note: string;
};

export type Bookmark = { surah: number; ayah: number };

type Data = {
  points: number;
  cxp: number;
  missionStart: string | null;
  logs: Logs;
  bonusClaimedFor: string | null;
  cycles: number;
  quranKu: boolean;
  bookmarks: Bookmark[];
  favs: number[];
  niats: Niat[];
  lastNiatDate: string | null;
  city: string;
  name: string;
  spinDate: string | null;
  spins: number;
  qari: string;
  night: boolean;
  arabSize: 0 | 1 | 2;
};

type Actions = {
  togglePrayer: (id: PrayerId) => void;
  startMission: () => void;
  buyQuranKu: () => "owned" | "short" | "ok";
  addNiat: (input: { pantiId: string; nominal: number; method: string; note: string }) => {
    bonus: boolean;
  };
  toggleBookmark: (surah: number, ayah: number) => "added" | "removed" | "full";
  toggleFav: (n: number) => "added" | "removed" | "full";
  recordSpin: () => boolean;
  spinsLeft: () => number;
  setCity: (city: string) => void;
  setName: (name: string) => void;
  setQari: (qari: string) => void;
  setNight: (night: boolean) => void;
  setArabSize: (arabSize: 0 | 1 | 2) => void;
  claimIfReady: () => void;
  resetAll: () => void;
};

const initial: Data = {
  points: 0,
  cxp: 0,
  missionStart: null,
  logs: {},
  bonusClaimedFor: null,
  cycles: 0,
  quranKu: false,
  bookmarks: [],
  favs: [],
  niats: [],
  lastNiatDate: null,
  city: "Gresik",
  name: "",
  spinDate: null,
  spins: 0,
  qari: "05",
  night: false,
  arabSize: 1,
};

function sameMark(a: Bookmark, surah: number, ayah: number) {
  return a.surah === surah && a.ayah === ayah;
}

export const useApp = create<Data & Actions>()(
  persist(
    (set, get) => ({
      ...initial,
      togglePrayer: (id) =>
        set((state) => {
          const today = todayKey();
          if (!state.missionStart || !inWindow(state.missionStart, today)) return state;
          const current = state.logs[today] ?? [];
          if (current.includes(id)) return state;
          const logs: Logs = { ...state.logs, [today]: [...current, id] };
          let points = state.points + PRAYER_POINTS;
          let cxp = state.cxp + PRAYER_CXP;
          let bonusClaimedFor = state.bonusClaimedFor;
          let cycles = state.cycles;
          const days = missionDates(state.missionStart);
          const all = days.every((d) => prayerCount(logs, d) >= 5);
          if (all && bonusClaimedFor !== state.missionStart) {
            points += BONUS_POINTS;
            cxp += BONUS_CXP;
            bonusClaimedFor = state.missionStart;
            cycles += 1;
          }
          return { logs, points, cxp, bonusClaimedFor, cycles };
        }),
      startMission: () =>
        set((state) => {
          const today = todayKey();
          if (phaseOf(state.missionStart, state.logs, today) === "active") return state;
          return { missionStart: today };
        }),
      buyQuranKu: () => {
        const state = get();
        if (state.quranKu) return "owned";
        if (state.points < SHOP_POINTS || state.cxp < SHOP_CXP) return "short";
        set({
          quranKu: true,
          points: state.points - SHOP_POINTS,
          cxp: state.cxp - SHOP_CXP,
        });
        return "ok";
      },
      addNiat: ({ pantiId, nominal, method, note }) => {
        const state = get();
        const today = todayKey();
        const bonus = state.lastNiatDate !== today;
        const entry: Niat = {
          id:
            typeof crypto !== "undefined" && "randomUUID" in crypto
              ? crypto.randomUUID()
              : `np-${Date.now()}`,
          at: new Date().toISOString(),
          pantiId,
          nominal,
          method,
          note: note.trim().slice(0, 80),
        };
        set({
          niats: [entry, ...state.niats].slice(0, 40),
          lastNiatDate: today,
          points: state.points + (bonus ? NIAT_POINTS : 0),
        });
        return { bonus };
      },
      toggleBookmark: (surah, ayah) => {
        const state = get();
        const exists = state.bookmarks.some((b) => sameMark(b, surah, ayah));
        if (exists) {
          set({ bookmarks: state.bookmarks.filter((b) => !sameMark(b, surah, ayah)) });
          return "removed";
        }
        if (!state.quranKu && state.bookmarks.length >= FREE_MARKS) return "full";
        set({ bookmarks: [...state.bookmarks, { surah, ayah }] });
        return "added";
      },
      toggleFav: (n) => {
        const state = get();
        if (state.favs.includes(n)) {
          set({ favs: state.favs.filter((x) => x !== n) });
          return "removed";
        }
        if (!state.quranKu && state.favs.length >= FREE_FAVS) return "full";
        set({ favs: [...state.favs, n] });
        return "added";
      },
      recordSpin: () => {
        const state = get();
        const today = todayKey();
        const used = state.spinDate === today ? state.spins : 0;
        if (!state.quranKu && used >= FREE_SPINS) return false;
        set({ spinDate: today, spins: used + 1 });
        return true;
      },
      spinsLeft: () => {
        const state = get();
        if (state.quranKu) return 99;
        const today = todayKey();
        const used = state.spinDate === today ? state.spins : 0;
        return Math.max(0, FREE_SPINS - used);
      },
      setCity: (city) => set({ city }),
      setName: (name) => set({ name: name.slice(0, 24) }),
      setQari: (qari) => set({ qari }),
      setNight: (night) => {
        if (night && !get().quranKu) return;
        set({ night });
      },
      setArabSize: (arabSize) => set({ arabSize }),
      claimIfReady: () =>
        set((state) => {
          if (!state.missionStart || state.bonusClaimedFor === state.missionStart) return state;
          const days = missionDates(state.missionStart);
          if (!days.every((d) => prayerCount(state.logs, d) >= 5)) return state;
          return {
            points: state.points + BONUS_POINTS,
            cxp: state.cxp + BONUS_CXP,
            bonusClaimedFor: state.missionStart,
            cycles: state.cycles + 1,
          };
        }),
      resetAll: () => set({ ...initial }),
    }),
    {
      name: "nurpray-v1",
      skipHydration: true,
      storage: createJSONStorage(() => ({
        getItem: (name) => (typeof window === "undefined" ? null : localStorage.getItem(name)),
        setItem: (name, value) => {
          if (typeof window !== "undefined") localStorage.setItem(name, value);
        },
        removeItem: (name) => {
          if (typeof window !== "undefined") localStorage.removeItem(name);
        },
      })),
      partialize: (state) => ({
        points: state.points,
        cxp: state.cxp,
        missionStart: state.missionStart,
        logs: state.logs,
        bonusClaimedFor: state.bonusClaimedFor,
        cycles: state.cycles,
        quranKu: state.quranKu,
        bookmarks: state.bookmarks,
        favs: state.favs,
        niats: state.niats,
        lastNiatDate: state.lastNiatDate,
        city: state.city,
        name: state.name,
        spinDate: state.spinDate,
        spins: state.spins,
        qari: state.qari,
        night: state.night,
        arabSize: state.arabSize,
      }),
    },
  ),
);

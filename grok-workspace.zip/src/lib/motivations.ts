export const CATS = [
  "Sholat",
  "Ngaji",
  "Sedekah",
  "Dakwah",
  "Akhlak",
  "Sabar",
  "Syukur",
  "Ilmu",
  "Ikhlas",
  "Doa",
  "Keluarga",
  "Taubat",
  "Ukhuwah",
] as const;

export type Cat = (typeof CATS)[number];

const LEADS: { cat: Cat; text: string }[] = [
  { cat: "Sholat", text: "Subuh adalah janji yang paling sunyi. Kamu menata hati sebelum dunia mulai meminta perhatian." },
  { cat: "Sholat", text: "Dzuhur mengembalikan napas di tengah hari yang terburu-buru. Berhenti sejenak bukan membuang waktu, itu mengembalikan arah." },
  { cat: "Sholat", text: "Ashar menjaga sisa hari agar tidak habis menjadi lelah yang sia-sia." },
  { cat: "Sholat", text: "Maghrib mengingatkan bahwa cahaya memang tenggelam, tetapi ibadah tidak ikut tenggelam." },
  { cat: "Sholat", text: "Isya menutup hari dengan berdiri, bukan dengan keluhan. Yang belum rapi bisa kamu serahkan, lalu kamu istirahat." },
  { cat: "Sholat", text: "Sholat berjamaah melatih ego untuk ikut satu gerakan, bukan selalu menjadi pusat." },
  { cat: "Sholat", text: "Khusyuk tidak datang sebagai sulap. Ia tumbuh dari rakaat yang kamu jaga meski pikiran sempat berkelana." },
  { cat: "Sholat", text: "Sholat di awal waktu adalah cara berkata bahwa Allah lebih dulu daripada daftar tugas." },
  { cat: "Sholat", text: "Dua rakaat yang jujur lebih berat timbangannya daripada rencana indah yang terus kamu tunda." },
  { cat: "Sholat", text: "Jika hati sedang kering, jangan menunggu basah dulu untuk sujud. Sujudlah. Tanah mengingatkan dari mana kamu berasal." },
  { cat: "Sholat", text: "Sholat menahan langkah menuju yang keji dan mungkar. Itu isyarat Al-Ankabut ayat 45, dan ia bekerja pelan pada orang yang menjaganya." },
  { cat: "Sholat", text: "Minta pertolongan lewat sabar dan sholat, sebagaimana isyarat Al-Baqarah ayat 153. Bukan supaya masalah lenyap seketika, tetapi supaya kamu tidak berjalan sendirian." },
  { cat: "Sholat", text: "Menunda sholat karena malu pada manusia adalah urutan yang terbalik. Yang melihatmu paling dalam bukan mereka." },
  { cat: "Sholat", text: "Sajadah yang sama setiap hari adalah guru keistiqamahan. Tidak perlu yang baru untuk hati yang mau kembali." },
  { cat: "Sholat", text: "Anak yang melihat orang tuanya sholat belajar agama dari gerakan, sebelum dari ceramah." },
  { cat: "Sholat", text: "Jika kamu bolong, jangan menambah bolong kedua hanya karena malu pada bolong yang pertama. Berdirilah lagi." },
  { cat: "Ngaji", text: "Mengaji sedikit tetapi rutin mengalahkan khatam yang hanya hidup di janji." },
  { cat: "Ngaji", text: "Tartil bukan lomba cepat. Bacalah dengan tenang, sebagaimana perintah membaca secara tartil di Al-Muzzammil ayat 4." },
  { cat: "Ngaji", text: "Satu ayat yang kamu pahami lalu kamu bawa ke sikap, lebih hidup daripada sepuluh halaman yang hanya lewat di lidah." },
  { cat: "Ngaji", text: "Ulangi ayat yang membuat dadamu berhenti. Di situ biasanya ada pesan yang belum kamu jawab." },
  { cat: "Ngaji", text: "Jangan rendahkan bacaanmu karena masih terbata. Terbata yang dijaga adalah jalan, bukan aib." },
  { cat: "Ngaji", text: "Mushaf yang dibuka lebih berguna daripada mushaf yang hanya dibanggakan di rak." },
  { cat: "Ngaji", text: "Dengar murottal, lalu ikuti dengan suaramu sendiri. Telinga dan lidah perlu bekerja bersama." },
  { cat: "Ngaji", text: "Mengaji setelah isya, walau satu halaman, menutup hari dengan kalam bukan dengan gulungan yang tak habis." },
  { cat: "Ngaji", text: "Jika sulit fokus, kecilkan target: tiga ayat, pelan, lalu diam sejenak." },
  { cat: "Ngaji", text: "Ajari satu ayat pada orang di rumah. Ilmu yang dibagikan biasanya lebih menempel." },
  { cat: "Ngaji", text: "Jangan jadikan panjangnya bacaan sebagai bahan membandingkan orang lain." },
  { cat: "Ngaji", text: "Hafalan yang rapuh tetap berharga kalau kamu mau mengulanginya besok, bukan membuangnya karena malu." },
  { cat: "Sedekah", text: "Sedekah yang tersembunyi menjaga niat dari tepuk tangan." },
  { cat: "Sedekah", text: "Orang yang menafkahkan harta di jalan Allah diumpamakan seperti benih yang menumbuhkan banyak bulir. Itu isyarat Al-Baqarah ayat 261. Kamu tidak harus melihat tunasnya hari ini." },
  { cat: "Sedekah", text: "Nominal kecil yang istiqamah lebih jujur daripada nominal besar yang hanya ingin dilihat." },
  { cat: "Sedekah", text: "Sedekah bukan sisa yang sudah tidak kamu suka. Beri dari sesuatu yang masih ada harganya bagimu." },
  { cat: "Sedekah", text: "Niat wakaf untuk anak-anak yang dijaga di panti adalah cara memperpanjang manfaat, bukan panggung." },
  { cat: "Sedekah", text: "Sebelum memberi, sebut nama Allah di dalam hati. Supaya tanganmu ingat ini amanah, bukan unjuk diri." },
  { cat: "Sedekah", text: "Menunda sedekah sampai kaya sering berarti tidak pernah mulai." },
  { cat: "Sedekah", text: "Catatan niat membantu kamu jujur pada dirimu, tetapi pahala tidak dihitung oleh aplikasi." },
  { cat: "Sedekah", text: "Beri makan, beri waktu, atau beri keringanan. Sedekah tidak selalu berupa uang." },
  { cat: "Sedekah", text: "Jangan sebut-sebut pemberianmu sampai penerima merasa kecil." },
  { cat: "Dakwah", text: "Dakwah yang paling didengar adalah akhlak yang tidak perlu pengeras suara." },
  { cat: "Dakwah", text: "Menasihati dengan keras sering memuaskan amarah, bukan memperbaiki orang." },
  { cat: "Dakwah", text: "Ajak dengan satu contoh yang kamu kerjakan dulu, baru satu kalimat yang pelan." },
  { cat: "Dakwah", text: "Tidak semua orang harus kamu menangkan dalam perdebatan. Kadang yang mereka butuhkan adalah ruang untuk pulang." },
  { cat: "Dakwah", text: "Dakwah di rumah dimulai dari nada bicara, bukan dari poster." },
  { cat: "Ukhuwah", text: "Jangan jadikan dosa orang lain sebagai bahan cerita. Menutup aib adalah bagian dari menjaga saudara." },
  { cat: "Dakwah", text: "Jika kamu belum mampu berdakwah panjang, jaga sholatmu dengan tekun, bukan dengan sombong." },
  { cat: "Dakwah", text: "Ilmu yang sedikit, disampaikan dengan rendah hati, lebih selamat daripada ilmu yang dipakai untuk memojokkan." },
  { cat: "Akhlak", text: "Jujur pada hal kecil melatih lidah agar tidak lihai berdalih pada hal besar." },
  { cat: "Akhlak", text: "Janji yang kamu tepati, meski sepele, adalah bentuk iman yang orang lain bisa rasakan." },
  { cat: "Akhlak", text: "Kata yang lembut tidak melemahkan kebenaran. Ia membuat kebenaran bisa dimasuki." },
  { cat: "Akhlak", text: "Menahan godaan membalas adalah kekuatan, bukan kekalahan." },
  { cat: "Akhlak", text: "Minta maaf lebih cepat daripada menyusun alasan." },
  { cat: "Ukhuwah", text: "Jangan tertawa di atas kekurangan orang. Kamu tidak tahu ujian apa yang tidak ia ceritakan." },
  { cat: "Akhlak", text: "Amanah sekecil titipan barang adalah latihan untuk amanah yang lebih besar." },
  { cat: "Akhlak", text: "Adab kepada orang tua tidak pensiun ketika kamu merasa sudah dewasa." },
  { cat: "Akhlak", text: "Diam pada saat marah adalah akhlak yang terlihat sepi, tetapi menyelamatkan banyak hal." },
  { cat: "Akhlak", text: "Ucapkan terima kasih kepada orang yang pekerjaannya sering dianggap biasa." },
  { cat: "Sabar", text: "Sabar bukan wajah tanpa rasa. Sabar adalah tidak membiarkan rasa itu merusak iman dan akhlakmu." },
  { cat: "Sabar", text: "Hasil yang ditunda bukan selalu penolakan. Kadang itu waktu yang sedang merakit kamu." },
  { cat: "Sabar", text: "Sesudah kesulitan ada kemudahan. Al-Insyirah ayat 5 dan 6 mengulanginya supaya kamu tidak lupa pada putaran kedua." },
  { cat: "Sabar", text: "Lelah yang kamu rasakan setelah berbuat benar bukan tanda kamu salah jalan." },
  { cat: "Sabar", text: "Jangan memutus doa hanya karena jawabannya belum memakai bentuk yang kamu mau." },
  { cat: "Ukhuwah", text: "Sabar kepada orang lain dimulai dari tidak menagih mereka menjadi kamu." },
  { cat: "Sabar", text: "Jika hari ini hanya mampu tidak jatuh lebih dalam, itu juga perjuangan yang sah." },
  { cat: "Sabar", text: "Menunggu dengan ibadah lebih ringan daripada menunggu dengan menggerutu." },
  { cat: "Syukur", text: "Jika kamu bersyukur, nikmat ditambah. Isyarat Ibrahim ayat 7 mengajak menghitung yang masih ada, bukan menyangkal yang berat." },
  { cat: "Syukur", text: "Sehat yang biasa saja adalah fasilitas besar untuk beribadah. Jangan tunggu sakit untuk mengingatnya." },
  { cat: "Syukur", text: "Rezeki yang cukup untuk hari ini sudah layak kamu sebut dengan lidah, bukan hanya dengan keluhan tentang besok." },
  { cat: "Syukur", text: "Bersyukur tidak melarangmu berusaha lebih. Ia melarangmu menghina yang sudah diberi." },
  { cat: "Syukur", text: "Air yang mengalir, tidur yang sempat, dan orang yang masih menyapamu adalah daftar yang mudah terlewat." },
  { cat: "Syukur", text: "Bandingkan dirimu dengan harimu yang kemarin, bukan dengan panggung orang lain." },
  { cat: "Syukur", text: "Ucapkan hamdalah pelan saat sesuatu yang kecil berjalan baik. Kebiasaan itu menajamkan mata." },
  { cat: "Syukur", text: "Syukur yang terlihat adalah berbagi sebagian dari yang kamu syukuri." },
  { cat: "Ilmu", text: "Ilmu yang tidak memperbaiki sholat, tutur, dan sikap masih mengantre untuk menjadi manfaat." },
  { cat: "Ilmu", text: "Catat satu pelajaran, lalu kerjakan satu bagiannya hari ini. Catatan tanpa amal cepat menjadi pajangan." },
  { cat: "Ilmu", text: "Bertanya dengan sopan adalah keberanian orang yang tahu dirinya belum selesai." },
  { cat: "Ilmu", text: "Jangan malu belajar dasar. Banyak orang tersesat karena pura-pura sudah tinggi." },
  { cat: "Ilmu", text: "Guru, buku, dan kawan yang mengingatkanmu adalah nikmat. Jangan habiskan mereka dengan sikap meremehkan." },
  { cat: "Ilmu", text: "Menyimak sampai orang selesai bicara adalah adab menuntut ilmu yang paling murah dan paling langka." },
  { cat: "Ilmu", text: "Ayat atau keterangan yang belum kamu pahami, jangan kamu sebarkan dengan nada pasti." },
  { cat: "Ilmu", text: "Ulangi pelajaran kemarin sebelum menambah yang baru. Rumah yang rapuh tidak dinaikkan atapnya." },
  { cat: "Ikhlas", text: "Ikhlas bukan tanpa rencana. Ikhlas adalah rencana yang tidak roboh saat tidak ada yang menonton." },
  { cat: "Ikhlas", text: "Jika pujian datang, kembalikan dalam hati: ini bukan milikmu sepenuhnya." },
  { cat: "Ikhlas", text: "Jika celaan datang, periksa yang benar, buang yang zalim, lalu lanjutkan yang baik tanpa dendam." },
  { cat: "Ikhlas", text: "Amal yang tercampur ria masih bisa kamu perbaiki dengan memperbarui niat, bukan dengan berhenti total." },
  { cat: "Ikhlas", text: "Berbuat baik diam-diam sesekali, supaya hatimu ingat rasanya tidak dilihat." },
  { cat: "Ikhlas", text: "Jangan mengungkit kebaikanmu sebagai tiket untuk diperlakukan istimewa." },
  { cat: "Ikhlas", text: "Niat yang murni tetap perlu cara yang benar. Ikhlas tidak membolehkan yang batil." },
  { cat: "Doa", text: "Doa yang khusyuk sering lahir dari hati yang mau mengaku kecil di hadapan Allah." },
  { cat: "Doa", text: "Doakan orang tuamu dengan nama mereka, pelan, di dalam sujud yang kamu panjangkan sedikit." },
  { cat: "Ukhuwah", text: "Doakan orang yang menyakitimu agar diberi petunjuk, bukan agar kamu merasa lebih suci." },
  { cat: "Doa", text: "Minta yang halal dengan usaha yang halal. Doa bukan pengganti kerja, dan kerja bukan pengganti doa." },
  { cat: "Doa", text: "Hati yang baru selesai berbuat baik sering lebih lembut untuk berdoa. Manfaatkan saat itu." },
  { cat: "Doa", text: "Jangan membatasi doa hanya pada urusan yang besar. Minta juga keteguhan untuk urusan yang kecil." },
  { cat: "Doa", text: "Jika belum sanggup berdoa panjang, satu panggilan tulus kepada Allah sudah membuka pintu." },
  { cat: "Keluarga", text: "Rumah yang damai dimulai dari orang yang mau menurunkan suaranya lebih dulu." },
  { cat: "Keluarga", text: "Menjaga sholat keluarga tidak butuh ceramah panjang. Butuh kamu berdiri, lalu mengajak dengan lembut." },
  { cat: "Keluarga", text: "Waktu untuk orang tua, meski singkat dan utuh, lebih berharga daripada hadiah yang datang tanpa kunjungan." },
  { cat: "Keluarga", text: "Anak meniru yang kamu ulang, bukan yang kamu tempel di dinding." },
  { cat: "Ukhuwah", text: "Memaafkan keluarga bukan menyetujui luka. Ia menghentikan luka itu menjadi warisan." },
  { cat: "Keluarga", text: "Makan bersama, meski sederhana, adalah majelis yang sering diremehkan." },
  { cat: "Keluarga", text: "Jangan bawa aib rumah ke luar hanya untuk menang dalam percakapan." },
  { cat: "Keluarga", text: "Doa untuk pasangan dan anak yang kamu ucapkan di belakang mereka adalah pelindung yang tidak mereka dengar." },
  { cat: "Taubat", text: "Taubat tidak menunggu kamu merasa layak. Justru ia untuk hari ketika kamu merasa tidak layak." },
  { cat: "Taubat", text: "Jangan berputus asa dari rahmat Allah. Az-Zumar ayat 53 memanggil orang yang melampaui batas agar kembali, bukan agar bersembunyi." },
  { cat: "Taubat", text: "Menyesal tanpa berhenti dari sebab yang sama hanyalah rasa, belum langkah." },
  { cat: "Taubat", text: "Ganti satu kebiasaan yang merusak dengan satu kebiasaan yang kecil dan jelas hari ini." },
  { cat: "Taubat", text: "Jika kamu jatuh lagi, hitung bukan untuk menghukum dirimu selamanya, tetapi untuk bangkit lebih cepat." },
  { cat: "Taubat", text: "Minta maaf kepada manusia yang kamu rugikan adalah bagian taubat yang tidak bisa diganti oleh air mata saja." },
  { cat: "Taubat", text: "Malam masih ada untuk orang yang mau berbisik memohon, lalu tidur dengan niat yang lebih bersih." },
  { cat: "Taubat", text: "Allah suka hamba yang kembali, bukan hamba yang berpura-pura tidak pernah lecet." },
  { cat: "Ukhuwah", text: "Saudara seiman bukan saingan pahala. Doakan kebaikan yang kamu iri, supaya iri itu berubah menjadi doa." },
];

const SUPPORTS = [
  "Allah tidak menyia-nyiakan usaha kecil yang kamu jaga saat tidak semangat.",
  "Kamu tidak harus sempurna hari ini. Kamu harus jujur dan mau mengulang.",
  "Pelan yang terus berjalan sampai lebih jauh daripada cepat yang berhenti di hari kedua.",
  "Jangan ukur harimu dari yang belum, sebelum menyebut yang sudah kamu jaga.",
  "Hati yang kembali lebih dicintai daripada hati yang hanya pandai tampil bersih.",
  "Satu langkah di arah yang benar tetap langkah, meski orang lain tidak bertepuk.",
  "Jika berat, kecilkan bebannya, jangan buang arahnya.",
  "Ibadah yang tersembunyi sering menjadi tulang yang menahanmu saat kamu terlihat rapuh.",
  "Kamu boleh lelah. Kamu tidak harus mengkhianati niatmu hanya karena lelah.",
  "Mulai lagi bukan berarti kemarin hangus. Mulai lagi berarti kamu masih hidup.",
  "Kelembutan pada dirimu sendiri membuatmu lebih mampu lembut pada orang lain.",
  "Jangan menunggu suasana hati. Suasana hati sering mengikuti gerakan, bukan sebaliknya.",
  "Apa yang kamu ulang akan menjadi dirimu, lebih daripada apa yang kamu niatkan sekali.",
  "Sedikit yang halal dan tenang lebih berkah daripada banyak yang membuat hatimu gelisah.",
  "Orang yang memperbaiki diam-diam biasanya lebih kuat daripada orang yang mengumumkan perbaikannya.",
  "Hari yang biasa adalah tempat keimanan benar-benar diuji.",
  "Jangan tinggalkan yang wajib demi memperindah yang sunnah.",
  "Doa dan usaha adalah dua tangan. Keduanya perlu terangkat.",
  "Menjaga batas Allah adalah bentuk sayang pada dirimu di masa depan.",
  "Jika tidak ada yang melihat, Allah tidak sedang absen.",
  "Kebaikan yang kamu tunda sampai nanti sering kehilangan orang yang membutuhkannya hari ini.",
];

const AMALS = [
  "Kerjakan satu sholat hari ini di awal waktunya.",
  "Baca tiga ayat dengan pelan, lalu diam sejenak sebelum melanjutkan.",
  "Sisihkan nominal kecil untuk orang yang membutuhkan, tanpa menceritakannya.",
  "Hubungi orang tua atau wali dengan sapaan yang utuh, bukan hanya stiker.",
  "Minta maaf pada satu orang yang masih kamu tunda.",
  "Matikan gulungan sebentar, lalu sholat tanpa buru-buru.",
  "Tuliskan satu nikmat yang masih ada, dan ucapkan hamdalah.",
  "Hafalkan arti satu ayat pendek yang sudah kamu baca.",
  "Sapa orang di rumah dengan hangat sebelum memberi nasihat.",
  "Rapikan sajadah dan mushaf, supaya ajakan kepada diri sendiri terlihat nyata.",
  "Doakan satu orang yang sedang membuatmu kesal, agar hatimu tidak mengeras.",
  "Tepati satu janji kecil yang mudah kamu anggap sepele.",
  "Beri minum atau makanan sederhana kepada siapa pun yang ada di sekitarmu.",
  "Ulangi bacaan yang masih terbata, tanpa merekamnya untuk dipamerkan.",
  "Duduk sepuluh menit tanpa keluhan, hanya untuk berzikir pelan.",
  "Kurangi satu pembicaraan yang menggunjing.",
  "Catat sholat lima waktu hari ini dengan jujur, termasuk yang bolong.",
  "Bacakan satu ayat untuk dirimu sendiri sebelum tidur.",
  "Beri jalan, beri tempat, atau beri antrean kepada orang lain sekali hari ini.",
  "Perbaiki satu kalimat kasar yang sudah terlanjur, dengan permintaan maaf yang jelas.",
  "Pelajari satu adab, lalu pakai hari ini juga.",
  "Simpan sebagian uang jajan untuk sedekah, meski hanya receh yang istiqamah.",
  "Sholat sunnah dua rakaat jika wajibnya sudah terjaga.",
  "Doakan anak-anak di panti asuhan tanpa mengumumkan nominal.",
  "Turunkan suaramu pada percakapan pertama yang mulai panas.",
  "Baca terjemah ayat yang sama dengan yang kamu baca arabnya.",
  "Jangan membuka aib siapa pun di obrolan hari ini.",
  "Datangi masjid untuk satu waktu, jika kamu mampu dan aman.",
  "Ucapkan terima kasih kepada orang yang memasak, menyapu, atau menolongmu.",
  "Ganti sepuluh menit yang biasa habis untuk iri dengan sepuluh menit mengaji.",
  "Perbarui niat sebelum amal yang ingin kamu pamerkan.",
  "Tidur lebih awal sedikit supaya subuh tidak selalu kalah.",
  "Tulis satu hal yang akan kamu hentikan, dan satu hal yang akan kamu mulai.",
  "Bagikan catatan ilmu yang bermanfaat, dengan jujur pada sumbernya.",
  "Rapikan satu sudut rumah yang selama ini kamu tinggalkan.",
  "Minta doa kepada orang yang kamu hormati, dengan sikap yang rendah.",
  "Akhiri hari dengan istighfar, lalu tidur tanpa mengungkit kesalahan orang.",
];

export type Motif = {
  n: number;
  cat: Cat;
  lead: string;
  support: string;
  amal: string;
};

export function motif(n: number): Motif {
  const i = ((Math.floor(n) - 1) % 777 + 777) % 777;
  const lead = LEADS[i % LEADS.length];
  return {
    n: i + 1,
    cat: lead.cat,
    lead: lead.text,
    support: SUPPORTS[i % SUPPORTS.length],
    amal: AMALS[i % AMALS.length],
  };
}

export function searchMotifs(query: string, cat: Cat | "Semua") {
  const needle = query.trim().toLowerCase();
  const out: Motif[] = [];
  for (let n = 1; n <= 777; n += 1) {
    const item = motif(n);
    if (cat !== "Semua" && item.cat !== cat) continue;
    if (!needle) {
      out.push(item);
      continue;
    }
    const hay = `${item.n} ${item.cat} ${item.lead} ${item.support} ${item.amal}`.toLowerCase();
    if (hay.includes(needle)) out.push(item);
  }
  return out;
}

export const MOTIF_READY = LEADS.length === 111 && SUPPORTS.length === 21 && AMALS.length === 37;

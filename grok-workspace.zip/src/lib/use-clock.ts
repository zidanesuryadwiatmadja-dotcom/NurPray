import { useEffect, useState } from "react";
import { todayKey } from "@/lib/dates";

export function useToday() {
  const [today, setToday] = useState<string | null>(null);
  useEffect(() => {
    const tick = () => setToday(todayKey());
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);
  return today;
}

export function useGreeting(name: string) {
  const [text, setText] = useState("Assalamu'alaikum");
  useEffect(() => {
    const hour = new Date().getHours();
    const part =
      hour < 4 ? "Selamat malam" : hour < 11 ? "Selamat pagi" : hour < 15 ? "Selamat siang" : hour < 18 ? "Selamat sore" : "Selamat malam";
    const who = name.trim();
    setText(who ? `${part}, ${who}` : part);
  }, [name]);
  return text;
}

export function useDailyNumber() {
  const [n, setN] = useState(1);
  useEffect(() => {
    const key = todayKey();
    let hash = 2166136261;
    for (let i = 0; i < key.length; i += 1) {
      hash ^= key.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    setN((Math.abs(hash) % 777) + 1);
  }, []);
  return n;
}

export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => setReduced(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);
  return reduced;
}

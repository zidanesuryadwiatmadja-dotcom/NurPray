export const PANTI = [
  {
    id: "nur-hati",
    name: "Panti Asuhan Nur Hati",
    city: "Gresik",
    focus: "Anak yatim dan dhuafa",
  },
  {
    id: "baitul",
    name: "Panti Asuhan Baitul Yatama",
    city: "Surabaya",
    focus: "Pendidikan dan asrama",
  },
  {
    id: "pelita",
    name: "Rumah Yatim Pelita Iman",
    city: "Sidoarjo",
    focus: "Makan harian dan sekolah",
  },
  {
    id: "amanah",
    name: "Panti Asuhan Al-Amanah",
    city: "Lamongan",
    focus: "Wakaf operasional harian",
  },
] as const;

export const METHODS = [
  "Dana",
  "GoPay",
  "OVO",
  "ShopeePay",
  "BCA",
  "Mandiri",
  "BRI",
  "BNI",
  "Tunai",
] as const;

export type Method = (typeof METHODS)[number];

export const CITIES = [
  "Gresik",
  "Surabaya",
  "Sidoarjo",
  "Lamongan",
  "Malang",
  "Jakarta",
  "Bandung",
  "Yogyakarta",
  "Semarang",
  "Solo",
  "Medan",
  "Palembang",
  "Makassar",
  "Banjarmasin",
  "Denpasar",
  "Pontianak",
] as const;

export function pantiById(id: string) {
  return PANTI.find((p) => p.id === id) ?? null;
}

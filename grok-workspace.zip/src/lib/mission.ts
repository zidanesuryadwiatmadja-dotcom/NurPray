import { missionDates } from "@/lib/dates";

export const PRAYER_POINTS = 200;
export const PRAYER_CXP = 2500;
export const BONUS_POINTS = 70_000;
export const BONUS_CXP = 699_899;
export const SHOP_POINTS = 50_000;
export const SHOP_CXP = 677_000;
export const NIAT_POINTS = 25;
export const FREE_SPINS = 3;
export const FREE_MARKS = 5;
export const FREE_FAVS = 5;

export const PRAYERS = [
  { id: "subuh", label: "Subuh", key: "Fajr" },
  { id: "dzuhur", label: "Dzuhur", key: "Dhuhr" },
  { id: "ashar", label: "Ashar", key: "Asr" },
  { id: "maghrib", label: "Maghrib", key: "Maghrib" },
  { id: "isya", label: "Isya", key: "Isha" },
] as const;

export type PrayerId = (typeof PRAYERS)[number]["id"];
export type Logs = Partial<Record<string, PrayerId[]>>;

export type Phase = "idle" | "active" | "bolong" | "complete" | "expired";

export function prayerCount(logs: Logs, date: string) {
  const list = logs[date];
  return Array.isArray(list) ? list.length : 0;
}

export function phaseOf(start: string | null, logs: Logs, today: string | null): Phase {
  if (!start || !today) return "idle";
  const days = missionDates(start);
  const all = days.every((d) => prayerCount(logs, d) >= 5);
  if (all) return "complete";
  const last = days[13];
  if (today > last) return "expired";
  if (today < start) return "idle";
  const missed = days.some((d) => d < today && prayerCount(logs, d) < 5);
  if (missed) return "bolong";
  return "active";
}

export function completeDays(start: string | null, logs: Logs) {
  if (!start) return 0;
  return missionDates(start).filter((d) => prayerCount(logs, d) >= 5).length;
}

export function inWindow(start: string | null, today: string | null) {
  if (!start || !today) return false;
  return missionDates(start).includes(today);
}

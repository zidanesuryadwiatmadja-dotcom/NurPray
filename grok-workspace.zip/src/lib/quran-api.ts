import { SURAHS } from "@/data/surahs";

export type Ayat = {
  nomorAyat: number;
  teksArab: string;
  teksLatin: string;
  teksIndonesia: string;
  audio: Record<string, string>;
};

export type SurahDetail = {
  nomor: number;
  nama: string;
  namaLatin: string;
  jumlahAyat: number;
  tempatTurun: string;
  arti: string;
  deskripsi: string;
  audioFull: Record<string, string>;
  ayat: Ayat[];
};

export const QARI = [
  { id: "05", name: "Misyari Rasyid Al-Afasi" },
  { id: "01", name: "Abdullah Al-Juhany" },
  { id: "02", name: "Abdul Muhsin Al-Qasim" },
  { id: "03", name: "Abdurrahman As-Sudais" },
  { id: "04", name: "Ibrahim Al-Dossari" },
  { id: "06", name: "Yasser Al-Dosari" },
] as const;

const cache = new Map<number, SurahDetail>();

export function plainText(html: string) {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&/g, "&")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

export async function fetchSurah(nomor: number, signal?: AbortSignal) {
  const hit = cache.get(nomor);
  if (hit) return hit;
  const res = await fetch(`https://equran.id/api/v2/surat/${nomor}`, { signal });
  if (!res.ok) throw new Error("Surat tidak terunduh");
  const json = (await res.json()) as { code?: number; data?: SurahDetail; message?: string };
  if (json.code !== 200 || !json.data?.ayat) throw new Error(json.message || "Surat tidak terunduh");
  cache.set(nomor, json.data);
  return json.data;
}

export function randomPointer() {
  const surah = SURAHS[Math.floor(Math.random() * SURAHS.length)];
  const ayah = 1 + Math.floor(Math.random() * surah.ayat);
  return { nomor: surah.nomor, ayah, latin: surah.latin };
}

export function surahMeta(nomor: number) {
  return SURAHS.find((s) => s.nomor === nomor) ?? null;
}

//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DugE49f-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/hadiah",
			"/jejak",
			"/kincir",
			"/misi",
			"/motivasi",
			"/quran",
			"/sedekah"
		],
		preloads: ["/assets/index-BnWDQ4It.js", "/assets/jsx-runtime-Dk72oS4N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BnWDQ4It.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DzgF6ZEr.js",
			"/assets/button-Cz_LhECh.js",
			"/assets/prayer-list-DRz7F9SZ.js",
			"/assets/motivations-smS47PRV.js",
			"/assets/use-clock-Bit5BlB2.js"
		]
	},
	"/hadiah": {
		filePath: "/workspace/src/routes/hadiah.tsx",
		children: void 0,
		preloads: [
			"/assets/hadiah-B2HAcT2k.js",
			"/assets/check-BY5Bm1iU.js",
			"/assets/button-Cz_LhECh.js"
		]
	},
	"/jejak": {
		filePath: "/workspace/src/routes/jejak.tsx",
		children: void 0,
		preloads: [
			"/assets/jejak-Zw5WrAK1.js",
			"/assets/button-Cz_LhECh.js",
			"/assets/motivations-smS47PRV.js",
			"/assets/charity-buKoBw7O.js",
			"/assets/quran-api-C36c6v6n.js"
		]
	},
	"/kincir": {
		filePath: "/workspace/src/routes/kincir.tsx",
		children: void 0,
		preloads: [
			"/assets/kincir-yihAwcDn.js",
			"/assets/button-Cz_LhECh.js",
			"/assets/use-clock-Bit5BlB2.js",
			"/assets/quran-api-C36c6v6n.js"
		]
	},
	"/misi": {
		filePath: "/workspace/src/routes/misi.tsx",
		children: void 0,
		preloads: [
			"/assets/misi-8WOmZcUC.js",
			"/assets/button-Cz_LhECh.js",
			"/assets/prayer-list-DRz7F9SZ.js",
			"/assets/use-clock-Bit5BlB2.js",
			"/assets/charity-buKoBw7O.js"
		]
	},
	"/motivasi": {
		filePath: "/workspace/src/routes/motivasi.tsx",
		children: void 0,
		preloads: [
			"/assets/motivasi-B5qFfg9L.js",
			"/assets/bookmark-6csrEIpM.js",
			"/assets/button-Cz_LhECh.js",
			"/assets/motivations-smS47PRV.js",
			"/assets/use-clock-Bit5BlB2.js"
		]
	},
	"/quran": {
		filePath: "/workspace/src/routes/quran.tsx",
		children: ["/quran/$nomor"],
		preloads: ["/assets/quran-B4d4Y9wM.js", "/assets/surahs-1oNpO43Z.js"]
	},
	"/sedekah": {
		filePath: "/workspace/src/routes/sedekah.tsx",
		children: void 0,
		preloads: [
			"/assets/sedekah-C_3RkLSV.js",
			"/assets/button-Cz_LhECh.js",
			"/assets/charity-buKoBw7O.js"
		]
	},
	"/quran/$nomor": {
		filePath: "/workspace/src/routes/quran.$nomor.tsx",
		children: void 0,
		preloads: [
			"/assets/quran._nomor-BNcJt4oP.js",
			"/assets/bookmark-6csrEIpM.js",
			"/assets/button-Cz_LhECh.js",
			"/assets/quran-api-C36c6v6n.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };

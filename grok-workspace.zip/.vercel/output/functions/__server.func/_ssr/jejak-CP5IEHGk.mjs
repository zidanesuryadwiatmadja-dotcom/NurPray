import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as useApp } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
import { r as motif } from "./motivations-DiKR0zzT.mjs";
import { t as CITIES } from "./charity-Dh2Kz82z.mjs";
import { a as surahMeta } from "./quran-api-D3TObghb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jejak-CP5IEHGk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function JejakPage() {
	const name = useApp((s) => s.name);
	const city = useApp((s) => s.city);
	const setName = useApp((s) => s.setName);
	const setCity = useApp((s) => s.setCity);
	const bookmarks = useApp((s) => s.bookmarks);
	const favs = useApp((s) => s.favs);
	const quranKu = useApp((s) => s.quranKu);
	const resetAll = useApp((s) => s.resetAll);
	const [ask, setAsk] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold leading-tight",
				children: "Jejak di perangkat"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: ["Nama, kota, penanda, dan poin tersimpan hanya di peramban ini. ", quranKu ? "QuranKu aktif." : "QuranKu belum ditukar."]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "Nama panggilan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: name,
					maxLength: 24,
					onChange: (event) => setName(event.target.value),
					placeholder: "Misalnya Zidane"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "Kota waktu sholat"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field",
					value: city,
					onChange: (event) => setCity(event.target.value),
					children: CITIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item,
						children: item
					}, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Ayat tertandai"
					}),
					bookmarks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Belum ada. Tandai dari dalam surat."
					}) : null,
					bookmarks.map((mark) => {
						const meta = surahMeta(mark.surah);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/quran/$nomor",
							params: { nomor: String(mark.surah) },
							hash: `ayat-${mark.ayah}`,
							className: "card min-h-14 px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: meta?.latin ?? `Surat ${mark.surah}`
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [" · ayat ", mark.ayah]
							})]
						}, `${mark.surah}-${mark.ayah}`);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Renungan tersimpan"
					}),
					favs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Belum ada favorit."
					}) : null,
					favs.map((n) => {
						const item = motif(n);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/motivasi",
							hash: `m-${n}`,
							className: "card min-h-14 px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold",
								children: [
									item.n,
									" · ",
									item.cat
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-muted",
								children: item.lead
							})]
						}, n);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Hapus data"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Poin, misi, niat, dan penanda di perangkat ini akan hilang."
					}),
					ask ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								resetAll();
								setAsk(false);
							},
							children: "Ya, hapus"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: "line",
							onClick: () => setAsk(false),
							children: "Batal"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "line",
						className: "mt-3",
						onClick: () => setAsk(true),
						children: "Hapus data perangkat"
					})
				]
			})
		]
	});
}
//#endregion
export { JejakPage as component };

import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as SHOP_CXP, d as phaseOf, f as prayerCount, h as useApp, i as PRAYER_CXP, n as BONUS_POINTS, o as SHOP_POINTS, p as prettyDate, s as cn, t as BONUS_CXP, u as missionDates } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as formatPoin, r as formatCxp } from "./router-BfRMUHbY.mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
import { t as CITIES } from "./charity-Dh2Kz82z.mjs";
import { i as useToday } from "./use-clock-MSQiqYYZ.mjs";
import { t as PrayerList } from "./prayer-list-AFApU7OD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/misi-CT2CbX5v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MisiPage() {
	const start = useApp((s) => s.missionStart);
	const logs = useApp((s) => s.logs);
	const city = useApp((s) => s.city);
	const setCity = useApp((s) => s.setCity);
	const begin = useApp((s) => s.startMission);
	const today = useToday();
	const phase = phaseOf(start, logs, today);
	const [ask, setAsk] = (0, import_react.useState)(false);
	const days = start ? missionDates(start) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold leading-tight",
				children: "Misi sholat 14 hari"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Catat Subuh, Dzuhur, Ashar, Maghrib, dan Isya pada hari yang sama. Satu hari yang lewat tanpa lima waktu memutus rantai. Bonus hanya untuk siklus yang utuh."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card grid gap-3 px-4 py-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Setiap sholat yang dicatat: ",
						formatPoin(200),
						" poin dan ",
						formatCxp(PRAYER_CXP),
						" CXP."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Siklus penuh tanpa bolong: ",
						formatPoin(BONUS_POINTS),
						" poin dan ",
						formatCxp(BONUS_CXP),
						" CXP."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"QuranKu ditukar minimal ",
						formatPoin(SHOP_POINTS),
						" poin dan ",
						formatCxp(SHOP_CXP),
						" CXP."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "Ketuk hanya setelah sholat benar-benar dikerjakan. Catatan hari itu tidak bisa dibatalkan, supaya poin tidak diputar ulang."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: "Kota untuk perkiraan waktu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: city,
						onChange: (e) => setCity(e.target.value),
						children: CITIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: item
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "Perkiraan metode Kemenag. Cocokkan dengan masjid atau jadwal setempatmu."
					})
				]
			}),
			!today ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Menyetel tanggal perangkat…"
			}) : null,
			today && phase === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => begin(),
				children: "Mulai dari hari ini"
			}) : null,
			today && (phase === "bolong" || phase === "expired" || phase === "complete") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						phase === "bolong" && "Ada hari yang belum utuh. Poin sholat yang sudah masuk tidak ditarik.",
						phase === "expired" && "14 hari sudah lewat sebelum lengkap. Kamu bisa membuka siklus baru.",
						phase === "complete" && "Siklus ini tuntas dan bonusnya sudah masuk. Siklus berikutnya boleh dimulai dari hari ini."
					]
				}), ask ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							begin();
							setAsk(false);
						},
						children: "Ya, mulai hari ini"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "line",
						onClick: () => setAsk(false),
						children: "Batal"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					tone: "line",
					onClick: () => setAsk(true),
					children: "Mulai siklus baru"
				})]
			}) : null,
			start && today ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-lg font-semibold",
				children: "Papan 14 hari"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid max-w-lg grid-cols-7 gap-2",
				children: days.map((date) => {
					const count = prayerCount(logs, date);
					const future = date > today;
					const miss = date < today && count < 5;
					const done = count >= 5;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("card flex min-h-16 flex-col items-center justify-center px-1 py-2 text-center", done && "border-jade bg-jade-soft", date === today && "border-jade"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold tabular-nums",
							children: prettyDate(date).split(" ")[0]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: future ? "Nanti" : done ? "Utuh" : miss ? "Bolong" : `${count}/5`
						})]
					}, date);
				})
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-lg font-semibold",
				children: "Catatan hari ini"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrayerList, { today })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Hadiahnya dibuka di dalam NurPray, bukan berkas unduhan.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/hadiah",
						className: "font-semibold text-jade",
						children: "Lihat QuranKu"
					})
				]
			})
		]
	});
}
//#endregion
export { MisiPage as component };

import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { s as cn } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-CgmPagmD.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45", {
	variants: { tone: {
		jade: "bg-jade text-surface",
		soft: "bg-jade-soft text-ink",
		gold: "bg-gold-soft text-ink",
		line: "border border-line bg-surface text-ink",
		ghost: "bg-transparent text-ink"
	} },
	defaultVariants: { tone: "jade" }
});
function Button({ className, tone, asChild, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({ tone }), className),
		type: asChild ? void 0 : type ?? "button",
		...props
	});
}
//#endregion
export { Button as t };

import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as useApp, l as inWindow, r as PRAYERS, s as cn } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as Check } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/prayer-list-AFApU7OD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HIJRI = [
	"",
	"Muharram",
	"Safar",
	"Rabiul Awal",
	"Rabiul Akhir",
	"Jumadil Awal",
	"Jumadil Akhir",
	"Rajab",
	"Syaban",
	"Ramadan",
	"Syawal",
	"Zulkaidah",
	"Zulhijah"
];
var cache = /* @__PURE__ */ new Map();
function usePrayerTimes(city) {
	const [clock, setClock] = (0, import_react.useState)({
		times: null,
		hijri: null,
		error: null
	});
	(0, import_react.useEffect)(() => {
		const now = /* @__PURE__ */ new Date();
		const dd = String(now.getDate()).padStart(2, "0");
		const mm = String(now.getMonth() + 1).padStart(2, "0");
		const key = `${now.getFullYear()}-${mm}-${dd}-${city}`;
		const hit = cache.get(key);
		if (hit) {
			setClock(hit);
			return;
		}
		let cancel = false;
		const url = `https://api.aladhan.com/v1/timingsByCity/${dd}-${mm}-${now.getFullYear()}?city=${encodeURIComponent(city)}&country=Indonesia&method=20`;
		fetch(url).then((res) => {
			if (!res.ok) throw new Error("jadwal");
			return res.json();
		}).then((json) => {
			if (cancel) return;
			const timings = json.data?.timings;
			if (!timings) throw new Error("kosong");
			const h = json.data?.date?.hijri;
			const month = HIJRI[h?.month?.number ?? 0] || "";
			const next = {
				times: timings,
				hijri: h?.day && month ? `${h.day} ${month} ${h.year} H` : null,
				error: null
			};
			cache.set(key, next);
			setClock(next);
		}).catch(() => {
			if (!cancel) setClock({
				times: null,
				hijri: null,
				error: "Jadwal kota ini belum termuat."
			});
		});
		return () => {
			cancel = true;
		};
	}, [city]);
	return clock;
}
function PrayerList({ today }) {
	const logs = useApp((s) => s.logs);
	const start = useApp((s) => s.missionStart);
	const city = useApp((s) => s.city);
	const toggle = useApp((s) => s.togglePrayer);
	const clock = usePrayerTimes(city);
	const open = inWindow(start, today);
	const done = new Set(today ? logs[today] ?? [] : []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children: PRAYERS.map((prayer) => {
			const checked = done.has(prayer.id);
			const time = clock.times?.[prayer.key]?.slice(0, 5);
			const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-semibold",
				children: prayer.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("block text-sm", checked ? "text-ink" : "text-muted"),
				children: [time ?? "Waktu menyusul", city ? ` · ${city}` : ""]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("inline-flex items-center gap-1 text-sm font-semibold", checked ? "text-jade" : "text-muted"),
				children: [checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					className: "size-4",
					"aria-hidden": "true"
				}) : null, checked ? "Sudah" : open ? "Catat" : "Jadwal"]
			})] });
			if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card flex min-h-14 items-center justify-between px-4",
				children: body
			}, prayer.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: !today || checked,
				onClick: () => toggle(prayer.id),
				className: cn("card flex min-h-14 w-full items-center justify-between px-4 text-left", checked && "border-jade bg-jade-soft disabled:opacity-100"),
				children: body
			}, prayer.id);
		})
	});
}
//#endregion
export { usePrayerTimes as n, PrayerList as t };

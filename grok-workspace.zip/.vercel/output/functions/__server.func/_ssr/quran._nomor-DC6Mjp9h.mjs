import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as useApp, s as cn } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Bookmark, n as Play, r as Pause } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-BfRMUHbY.mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
import { n as fetchSurah, r as plainText, t as QARI } from "./quran-api-D3TObghb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quran._nomor-DC6Mjp9h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ARAB = [
	"text-2xl",
	"text-3xl",
	"text-4xl"
];
var BODY = [
	"text-sm",
	"text-base",
	"text-lg"
];
function SurahPage() {
	const { nomor } = Route.useParams();
	const n = Number(nomor);
	const quranKu = useApp((s) => s.quranKu);
	const qari = useApp((s) => s.qari);
	const setQari = useApp((s) => s.setQari);
	const night = useApp((s) => s.night);
	const setNight = useApp((s) => s.setNight);
	const arabSize = useApp((s) => s.arabSize);
	const setArabSize = useApp((s) => s.setArabSize);
	const bookmarks = useApp((s) => s.bookmarks);
	const toggleBookmark = useApp((s) => s.toggleBookmark);
	const [surah, setSurah] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [openDesc, setOpenDesc] = (0, import_react.useState)(false);
	const [markNote, setMarkNote] = (0, import_react.useState)("");
	const [playing, setPlaying] = (0, import_react.useState)(null);
	const [latinOn, setLatinOn] = (0, import_react.useState)(true);
	const audio = (0, import_react.useRef)(null);
	const dark = quranKu && night;
	const voice = quranKu ? qari : "05";
	(0, import_react.useEffect)(() => {
		if (!Number.isInteger(n) || n < 1 || n > 114) {
			setLoading(false);
			setError("Surat tidak dikenal.");
			return;
		}
		const ctrl = new AbortController();
		setLoading(true);
		setError("");
		fetchSurah(n, ctrl.signal).then((data) => {
			setSurah(data);
			setLoading(false);
		}).catch((err) => {
			if (ctrl.signal.aborted) return;
			setLoading(false);
			setError(err instanceof Error ? err.message : "Surat gagal dimuat.");
		});
		return () => ctrl.abort();
	}, [n]);
	(0, import_react.useEffect)(() => {
		return () => {
			audio.current?.pause();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!surah || !window.location.hash) return;
		document.getElementById(window.location.hash.slice(1))?.scrollIntoView({ block: "center" });
	}, [surah]);
	function play(url) {
		if (!url) return;
		const node = audio.current ?? new Audio();
		audio.current = node;
		if (playing === url) {
			node.pause();
			setPlaying(null);
			return;
		}
		node.src = url;
		node.onended = () => setPlaying(null);
		node.play().then(() => setPlaying(url)).catch(() => setPlaying(null));
	}
	if (!Number.isInteger(n) || n < 1 || n > 114) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Surat tidak dikenal." });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/quran",
				className: "text-sm font-semibold text-jade",
				children: "Semua surat"
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-40 rounded-full bg-line motion-safe:animate-pulse" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 rounded-card bg-line motion-safe:animate-pulse" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 rounded-card bg-line motion-safe:animate-pulse" })
				]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					onClick: () => window.location.reload(),
					children: "Coba lagi"
				})]
			}) : null,
			surah ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: cn("card px-5 py-5", dark && "border-gold-soft bg-ink text-surface"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-jade",
							children: surah.tempatTurun
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-2xl font-semibold leading-tight",
							children: surah.namaLatin
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-arab text-3xl leading-loose", dark ? "text-gold-soft" : "text-ink"),
							dir: "rtl",
							lang: "ar",
							children: surah.nama
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("text-sm", dark ? "text-gold-soft" : "text-muted"),
							children: [
								surah.arti,
								" · ",
								surah.jumlahAyat,
								" ayat"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-3 text-sm", !openDesc && "line-clamp-4", dark ? "text-gold-soft" : "text-muted"),
							children: plainText(surah.deskripsi)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-2 min-h-11 text-sm font-semibold text-jade",
							onClick: () => setOpenDesc((v) => !v),
							children: openDesc ? "Ringkas" : "Selengkapnya"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: latinOn ? "soft" : "line",
							onClick: () => setLatinOn((v) => !v),
							children: "Latin"
						}),
						[
							0,
							1,
							2
						].map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: arabSize === size ? "soft" : "line",
							onClick: () => setArabSize(size),
							"aria-pressed": arabSize === size,
							children: size === 0 ? "A" : size === 1 ? "A+" : "A++"
						}, size)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: dark ? "gold" : "line",
							onClick: () => quranKu ? setNight(!night) : setMarkNote("Mode malam ada di QuranKu."),
							children: "Mode malam"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: "Qari"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: voice,
						onChange: (e) => {
							if (!quranKu && e.target.value !== "05") {
								setMarkNote("Qari lain terbuka bersama QuranKu. Misyari tetap bisa didengar.");
								return;
							}
							setQari(e.target.value);
						},
						children: QARI.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.id,
							disabled: !quranKu && item.id !== "05",
							children: [item.name, !quranKu && item.id !== "05" ? " · QuranKu" : ""]
						}, item.id))
					})]
				}),
				surah.audioFull?.[voice] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					tone: "line",
					onClick: () => play(surah.audioFull[voice]),
					children: [playing === surah.audioFull[voice] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), playing === surah.audioFull[voice] ? "Jeda surat" : "Putar surat"]
				}) : null,
				markNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: markNote
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "grid gap-3",
					children: surah.ayat.map((ayat) => {
						const saved = bookmarks.some((b) => b.surah === surah.nomor && b.ayah === ayat.nomorAyat);
						const src = ayat.audio?.[voice];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							id: `ayat-${ayat.nomorAyat}`,
							className: cn("card px-4 py-4", dark && "border-gold-soft bg-ink text-surface"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-8 items-center justify-center rounded-full bg-jade-soft text-sm font-semibold text-jade",
										children: ayat.nomorAyat
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex gap-1",
										children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex size-11 items-center justify-center",
											onClick: () => play(src),
											"aria-label": `Putar ayat ${ayat.nomorAyat}`,
											children: playing === src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
										}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex size-11 items-center justify-center",
											"aria-pressed": saved,
											"aria-label": saved ? "Hapus penanda" : "Tandai ayat",
											onClick: () => {
												const status = toggleBookmark(surah.nomor, ayat.nomorAyat);
												setMarkNote(status === "full" ? `Penanda gratis penuh (5). QuranKu menyimpan tanpa batas.` : status === "added" ? "Ayat ditandai di jejakmu." : "");
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn("size-4", saved && "fill-jade text-jade") })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									dir: "rtl",
									lang: "ar",
									className: cn("mt-2 text-right font-arab leading-loose", ARAB[arabSize], dark ? "text-surface" : "text-ink"),
									children: ayat.teksArab
								}),
								latinOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("mt-2", BODY[arabSize], dark ? "text-gold-soft" : "text-muted"),
									children: ayat.teksLatin
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("mt-2", BODY[arabSize], dark ? "text-gold-soft" : "text-ink"),
									children: plainText(ayat.teksIndonesia)
								})
							]
						}, ayat.nomorAyat);
					})
				})
			] }) : null
		]
	});
}
//#endregion
export { SurahPage as component };

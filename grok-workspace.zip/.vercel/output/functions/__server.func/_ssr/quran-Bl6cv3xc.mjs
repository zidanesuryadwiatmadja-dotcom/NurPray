import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as SURAHS } from "./surahs-0zATGrFG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quran-Bl6cv3xc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuranPage() {
	const [query, setQuery] = (0, import_react.useState)("");
	const items = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		if (!needle) return SURAHS;
		return SURAHS.filter((surah) => `${surah.nomor} ${surah.latin} ${surah.arti} ${surah.turun}`.toLowerCase().includes(needle));
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold leading-tight",
				children: "Mushaf"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Arab, latin, dan terjemah bahasa Indonesia. Teks serta murottal dimuat dari equran.id. Mushaf ini bebas dibaca."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "Cari surat"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Nama, arti, atau nomor",
					inputMode: "search"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [items.length, " surat"]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Tidak ada surat dengan kata itu."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2",
				children: items.map((surah) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/quran/$nomor",
					params: { nomor: String(surah.nomor) },
					className: "card flex min-h-16 items-center gap-3 px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 shrink-0 items-center justify-center rounded-full bg-jade-soft text-sm font-semibold text-jade",
							children: surah.nomor
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: surah.latin
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-sm text-muted",
								children: [
									surah.arti,
									" · ",
									surah.ayat,
									" ayat · ",
									surah.turun
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							dir: "rtl",
							lang: "ar",
							className: "shrink-0 font-arab text-xl",
							children: surah.arab
						})
					]
				}) }, surah.nomor))
			})
		]
	});
}
//#endregion
export { QuranPage as component };

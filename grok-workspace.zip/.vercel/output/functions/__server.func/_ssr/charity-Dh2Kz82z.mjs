//#region node_modules/.nitro/vite/services/ssr/assets/charity-Dh2Kz82z.js
var PANTI = [
	{
		id: "nur-hati",
		name: "Panti Asuhan Nur Hati",
		city: "Gresik",
		focus: "Anak yatim dan dhuafa"
	},
	{
		id: "baitul",
		name: "Panti Asuhan Baitul Yatama",
		city: "Surabaya",
		focus: "Pendidikan dan asrama"
	},
	{
		id: "pelita",
		name: "Rumah Yatim Pelita Iman",
		city: "Sidoarjo",
		focus: "Makan harian dan sekolah"
	},
	{
		id: "amanah",
		name: "Panti Asuhan Al-Amanah",
		city: "Lamongan",
		focus: "Wakaf operasional harian"
	}
];
var METHODS = [
	"Dana",
	"GoPay",
	"OVO",
	"ShopeePay",
	"BCA",
	"Mandiri",
	"BRI",
	"BNI",
	"Tunai"
];
var CITIES = [
	"Gresik",
	"Surabaya",
	"Sidoarjo",
	"Lamongan",
	"Malang",
	"Jakarta",
	"Bandung",
	"Yogyakarta",
	"Semarang",
	"Solo",
	"Medan",
	"Palembang",
	"Makassar",
	"Banjarmasin",
	"Denpasar",
	"Pontianak"
];
function pantiById(id) {
	return PANTI.find((p) => p.id === id) ?? null;
}
//#endregion
export { pantiById as i, METHODS as n, PANTI as r, CITIES as t };

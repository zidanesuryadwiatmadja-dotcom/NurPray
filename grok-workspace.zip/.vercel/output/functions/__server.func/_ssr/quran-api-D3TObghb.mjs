import { t as SURAHS } from "./surahs-0zATGrFG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quran-api-D3TObghb.js
var QARI = [
	{
		id: "05",
		name: "Misyari Rasyid Al-Afasi"
	},
	{
		id: "01",
		name: "Abdullah Al-Juhany"
	},
	{
		id: "02",
		name: "Abdul Muhsin Al-Qasim"
	},
	{
		id: "03",
		name: "Abdurrahman As-Sudais"
	},
	{
		id: "04",
		name: "Ibrahim Al-Dossari"
	},
	{
		id: "06",
		name: "Yasser Al-Dosari"
	}
];
var cache = /* @__PURE__ */ new Map();
function plainText(html) {
	return html.replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/&/g, "&").replace(/"/g, "\"").replace(/&#39;/g, "'").replace(/\s+/g, " ").trim();
}
async function fetchSurah(nomor, signal) {
	const hit = cache.get(nomor);
	if (hit) return hit;
	const res = await fetch(`https://equran.id/api/v2/surat/${nomor}`, { signal });
	if (!res.ok) throw new Error("Surat tidak terunduh");
	const json = await res.json();
	if (json.code !== 200 || !json.data?.ayat) throw new Error(json.message || "Surat tidak terunduh");
	cache.set(nomor, json.data);
	return json.data;
}
function randomPointer() {
	const surah = SURAHS[Math.floor(Math.random() * SURAHS.length)];
	const ayah = 1 + Math.floor(Math.random() * surah.ayat);
	return {
		nomor: surah.nomor,
		ayah,
		latin: surah.latin
	};
}
function surahMeta(nomor) {
	return SURAHS.find((s) => s.nomor === nomor) ?? null;
}
//#endregion
export { surahMeta as a, randomPointer as i, fetchSurah as n, plainText as r, QARI as t };

import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as useApp } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as KincirMark } from "./router-BfRMUHbY.mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
import { i as randomPointer, n as fetchSurah } from "./quran-api-D3TObghb.mjs";
import { r as useReducedMotion } from "./use-clock-MSQiqYYZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kincir-DeMTJ-g_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function KincirPage() {
	const quranKu = useApp((s) => s.quranKu);
	const recordSpin = useApp((s) => s.recordSpin);
	const spinsLeft = useApp((s) => s.spinsLeft());
	const reduced = useReducedMotion();
	const [deg, setDeg] = (0, import_react.useState)(0);
	const [spinning, setSpinning] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)(null);
	const live = (0, import_react.useRef)(true);
	const lock = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		live.current = true;
		return () => {
			live.current = false;
		};
	}, []);
	async function spin() {
		if (lock.current || spinning) return;
		if (!quranKu && spinsLeft <= 0) {
			setError("Putaran gratis hari ini habis. QuranKu membuka kincir tanpa batas.");
			return;
		}
		lock.current = true;
		setError("");
		setSpinning(true);
		const pointer = randomPointer();
		setDeg((value) => value + 1800 + Math.floor(Math.random() * 360));
		const wait = reduced ? 200 : 2800;
		const ctrl = new AbortController();
		const timer = window.setTimeout(() => ctrl.abort(), 12e3);
		try {
			const [surah] = await Promise.all([fetchSurah(pointer.nomor, ctrl.signal), new Promise((resolve) => window.setTimeout(resolve, wait))]);
			const ayat = surah.ayat.find((item) => item.nomorAyat === pointer.ayah) ?? surah.ayat[0];
			if (!ayat) throw new Error("Ayat kosong");
			if (!recordSpin()) {
				setError("Putaran gratis hari ini habis.");
				return;
			}
			setResult({
				surah,
				ayat
			});
		} catch {
			setError("Ayat belum terunduh. Periksa sambungan, lalu putar lagi. Putaran ini tidak terpakai.");
		} finally {
			window.clearTimeout(timer);
			lock.current = false;
			if (live.current) setSpinning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold leading-tight",
				children: "Kincir ayat"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Putar roset ini untuk membuka satu ayat secara acak. Bukan undian hadiah — ini cara yang tenang untuk bertemu ayat."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card flex flex-col items-center px-4 py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-64",
						style: {
							transform: `rotate(${deg}deg)`,
							transitionProperty: "transform",
							transitionDuration: reduced ? "1ms" : "2800ms",
							transitionTimingFunction: "cubic-bezier(0.12, 0.7, 0.12, 1)"
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KincirMark, { className: "size-full" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-6",
						onClick: () => void spin(),
						disabled: spinning,
						children: spinning ? "Berputar…" : "Putar kincir"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-sm text-muted",
						children: quranKu ? "QuranKu aktif · putaran tanpa batas harian." : `Putaran gratis hari ini: ${spinsLeft} dari 3.`
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink",
				children: error
			}) : null,
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "card px-5 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-jade",
						children: [
							result.surah.namaLatin,
							" · ayat ",
							result.ayat.nomorAyat
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: result.surah.arti
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						dir: "rtl",
						lang: "ar",
						className: "mt-4 text-right font-arab text-3xl leading-loose",
						children: result.ayat.teksArab
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: result.ayat.teksLatin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3",
						children: result.ayat.teksIndonesia
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						tone: "line",
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/quran/$nomor",
							params: { nomor: String(result.surah.nomor) },
							hash: `ayat-${result.ayat.nomorAyat}`,
							children: "Buka di mushaf"
						})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Hasil ayat akan muncul di sini setelah kincir berhenti."
			}),
			!quranKu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Ingin memutar seharian?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/hadiah",
						className: "font-semibold text-jade",
						children: "Tukar QuranKu"
					}),
					" ",
					"setelah misi 14 hari penuh."
				]
			}) : null
		]
	});
}
//#endregion
export { KincirPage as component };

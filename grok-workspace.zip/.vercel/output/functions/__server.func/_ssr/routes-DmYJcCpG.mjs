import { c as completeDays, d as phaseOf, h as useApp, i as PRAYER_CXP, l as inWindow, n as BONUS_POINTS, t as BONUS_CXP } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as HandHeart, f as BookOpen, l as Gift, o as Library } from "../_libs/lucide-react.mjs";
import { i as formatPoin, o as KincirMark, r as formatCxp } from "./router-BfRMUHbY.mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
import { r as motif } from "./motivations-DiKR0zzT.mjs";
import { i as useToday, n as useGreeting, t as useDailyNumber } from "./use-clock-MSQiqYYZ.mjs";
import { n as usePrayerTimes, t as PrayerList } from "./prayer-list-AFApU7OD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DmYJcCpG.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const name = useApp((s) => s.name);
	const city = useApp((s) => s.city);
	const points = useApp((s) => s.points);
	const cxp = useApp((s) => s.cxp);
	const start = useApp((s) => s.missionStart);
	const logs = useApp((s) => s.logs);
	const cycles = useApp((s) => s.cycles);
	const quranKu = useApp((s) => s.quranKu);
	const today = useToday();
	const greet = useGreeting(name);
	const daily = motif(useDailyNumber());
	const clock = usePrayerTimes(city);
	const phase = phaseOf(start, logs, today);
	const utuh = completeDays(start, logs);
	const open = inWindow(start, today);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card px-5 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center font-arab text-2xl leading-loose text-ink",
						lang: "ar",
						dir: "rtl",
						children: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-center text-2xl font-semibold leading-tight",
						children: greet
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-center text-sm text-muted",
						children: [
							clock.hijri ? `${clock.hijri} · ` : "",
							city,
							quranKu ? " · QuranKu aktif" : "",
							cycles > 0 ? ` · ${cycles} misi tuntas` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/jejak",
							className: "text-sm font-semibold text-jade",
							children: "Nama, kota, dan ayat tersimpan"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/hadiah",
					className: "card min-h-20 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: "Poin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xl font-semibold tabular-nums",
						children: formatPoin(points)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/hadiah",
					className: "card min-h-20 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: "CXP"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xl font-semibold tabular-nums",
						children: formatCxp(cxp)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card px-5 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Misi 14 hari"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"Lima waktu tanpa bolong. Setiap catatan ",
								formatPoin(200),
								" poin dan ",
								formatCxp(PRAYER_CXP),
								" CXP. Penuh 14 hari: ",
								formatPoin(BONUS_POINTS),
								" poin dan ",
								formatCxp(BONUS_CXP),
								" CXP."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm font-semibold tabular-nums text-jade",
							children: [utuh, "/14"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-2 overflow-hidden rounded-full bg-line",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-jade",
							style: { width: `${utuh / 14 * 100}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm",
						children: [
							!today && "Menyetel tanggal perangkat…",
							today && phase === "idle" && "Belum dimulai. Catatan baru terhitung setelah misi dibuka.",
							today && phase === "active" && start && `Hari ke-${missionDay(start, today)} sedang berjalan.`,
							today && phase === "bolong" && "Rantai terputus. Poin yang sudah masuk tetap ada. Kamu bisa mulai siklus baru.",
							today && phase === "expired" && "Jendela 14 hari sudah lewat sebelum lengkap.",
							today && phase === "complete" && "Misi penuh. Bonus sudah masuk ke poin dan CXP."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						tone: "jade",
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/misi",
							children: phase === "idle" ? "Buka misi" : "Lihat papan misi"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Hari ini"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Perkiraan Kemenag"
					})]
				}),
				!open && phase !== "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-muted",
					children: "Jadwal ditampilkan. Centang aktif setelah misi hari ini dibuka."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrayerList, { today })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card border-l-4 border-l-jade px-5 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold tracking-wide text-jade",
						children: ["Renungan ", daily.n]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-lg font-semibold",
						children: daily.cat
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: daily.lead
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						tone: "line",
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/motivasi",
							children: "Baca 777 renungan"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/kincir",
						className: "card flex min-h-24 items-center gap-3 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KincirMark, { className: "size-12 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: "Kincir ayat"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: "Putar, lalu baca ayat yang terbuka."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quran",
						className: "card flex min-h-24 items-center gap-3 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
							className: "size-6 shrink-0 text-jade",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: "Mushaf QuranKu"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: "114 surat, latin, terjemah, dan murottal."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/sedekah",
						className: "card flex min-h-24 items-center gap-3 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHeart, {
							className: "size-6 shrink-0 text-jade",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: "Sedekah wakaf"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: "Jurnal niat untuk panti asuhan. Tidak memotong saldo."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/hadiah",
						className: "card flex min-h-24 items-center gap-3 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, {
							className: "size-6 shrink-0 text-gold",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: "Tukar QuranKu"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: "Minimal 50.000 poin dan 677.000,0 CXP."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/motivasi",
						className: "card flex min-h-24 items-center gap-3 px-4 py-4 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, {
							className: "size-6 shrink-0 text-jade",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: "777 motivasi harian"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: "Sholat, ngaji, sedekah, dakwah, akhlak, dan jalan pulang."
						})] })]
					})
				]
			})
		]
	});
}
function missionDay(start, today) {
	const [ys, ms, ds] = start.split("-").map(Number);
	const [yt, mt, dt] = today.split("-").map(Number);
	const a = new Date(ys, ms - 1, ds).getTime();
	const b = new Date(yt, mt - 1, dt).getTime();
	const diff = Math.round((b - a) / 864e5);
	return Math.min(14, Math.max(1, diff + 1));
}
//#endregion
export { Home as component };

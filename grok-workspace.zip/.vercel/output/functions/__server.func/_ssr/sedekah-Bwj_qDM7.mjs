import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as useApp, s as cn } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as formatRupiah } from "./router-BfRMUHbY.mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
import { i as pantiById, n as METHODS, r as PANTI } from "./charity-Dh2Kz82z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sedekah-Bwj_qDM7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PRESETS = [
	1e4,
	25e3,
	5e4,
	1e5
];
function SedekahPage() {
	const niats = useApp((s) => s.niats);
	const addNiat = useApp((s) => s.addNiat);
	const [pantiId, setPantiId] = (0, import_react.useState)(PANTI[0].id);
	const [nominal, setNominal] = (0, import_react.useState)("10000");
	const [method, setMethod] = (0, import_react.useState)("Dana");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	function submit() {
		const amount = Number(nominal.replace(/\D/g, ""));
		if (!Number.isInteger(amount) || amount < 1e3 || amount > 1e8) {
			setError("Isi nominal antara Rp1.000 dan Rp100.000.000.");
			setReceipt(null);
			return;
		}
		const place = pantiById(pantiId);
		if (!place) {
			setError("Pilih panti terlebih dahulu.");
			return;
		}
		const result = addNiat({
			pantiId,
			nominal: amount,
			method,
			note
		});
		const when = (/* @__PURE__ */ new Date()).toLocaleString("id-ID");
		const code = `NP-${Date.now().toString(36).toUpperCase()}`;
		const text = [
			"Nota niat sedekah NurPray",
			place.name,
			place.city,
			formatRupiah(amount),
			`Rencana lewat ${method}`,
			note.trim() ? `Catatan: ${note.trim()}` : "",
			`Nomor catatan: ${code}`,
			when,
			"Tidak ada uang yang berpindah dari aplikasi ini.",
			result.bonus ? `Pengingat harian: +25 poin. Bukan pahala.` : "Pengingat poin hari ini sudah tercatat."
		].filter(Boolean).join("\n");
		setError("");
		setCopied(false);
		setReceipt(text);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold leading-tight",
				children: "Sedekah wakaf"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Jurnal niat untuk panti asuhan. Seikhlasnya, lalu kamu yang mengirimnya sendiri."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "card bg-gold-soft px-4 py-4 text-sm text-ink",
				children: "NurPray tidak memotong Dana, GoPay, OVO, ShopeePay, atau rekening bank. Tidak ada transfer otomatis. Nama panti di sini contoh jurnal, bukan nomor rekening resmi. Untuk sedekah sungguhan, kirim lewat kanal lembaga yang kamu percaya, lalu catat nominalnya di sini sebagai pengingat."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					submit();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-semibold",
							children: "Panti"
						}), PANTI.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: cn("card flex min-h-16 cursor-pointer items-center gap-3 px-4 py-3", pantiId === place.id && "border-jade"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "panti",
								className: "size-4 accent-jade",
								checked: pantiId === place.id,
								onChange: () => setPantiId(place.id)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: place.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-sm text-muted",
								children: [
									place.city,
									" · ",
									place.focus
								]
							})] })]
						}, place.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "Nominal seikhlasnya"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field tabular-nums",
								inputMode: "numeric",
								value: nominal,
								onChange: (event) => setNominal(event.target.value.replace(/[^\d]/g, "")),
								"aria-label": "Nominal rupiah"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: nominal ? formatRupiah(Number(nominal) || 0) : "Rp0"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex flex-wrap gap-2",
								children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 rounded-full border border-line bg-surface px-3 text-sm",
									onClick: () => setNominal(String(preset)),
									children: formatRupiah(preset)
								}, preset))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-semibold",
							children: "Rencana pembayaran"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: METHODS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": method === item,
								onClick: () => setMethod(item),
								className: cn("min-h-11 rounded-full border px-3 text-sm", method === item ? "border-jade bg-jade text-surface" : "border-line bg-surface text-ink"),
								children: item
							}, item))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: "Catatan singkat"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: note,
							maxLength: 80,
							onChange: (event) => setNote(event.target.value),
							placeholder: "Misalnya untuk makan anak"
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Simpan niat"
					})
				]
			}),
			receipt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Nota niat"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-3 whitespace-pre-wrap font-sans text-sm",
						children: receipt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "line",
						className: "mt-3",
						onClick: () => {
							navigator.clipboard?.writeText(receipt).then(() => setCopied(true)).catch(() => setCopied(false));
						},
						children: copied ? "Tersalin" : "Salin ringkasan"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Riwayat di perangkat ini"
					}),
					niats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Belum ada niat tersimpan."
					}) : null,
					niats.map((item) => {
						const place = pantiById(item.pantiId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "card px-4 py-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: place?.name ?? "Panti"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "tabular-nums",
									children: [
										formatRupiah(item.nominal),
										" · ",
										item.method
									]
								}),
								item.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted",
									children: item.note
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted",
									children: new Date(item.at).toLocaleString("id-ID")
								})
							]
						}, item.id);
					})
				]
			})
		]
	});
}
//#endregion
export { SedekahPage as component };

import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as SHOP_CXP, h as useApp, n as BONUS_POINTS, o as SHOP_POINTS, t as BONUS_CXP } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Lock, u as Check } from "../_libs/lucide-react.mjs";
import { i as formatPoin, r as formatCxp } from "./router-BfRMUHbY.mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hadiah-BRmEVMql.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PERKS = [
	"Kincir ayat tanpa batas harian",
	"Enam qari murottal, bukan hanya satu",
	"Mode malam untuk mushaf",
	"Penanda ayat tanpa batas",
	"Simpan renungan favorit tanpa batas",
	"Lencana QuranKu di beranda"
];
function HadiahPage() {
	const points = useApp((s) => s.points);
	const cxp = useApp((s) => s.cxp);
	const owned = useApp((s) => s.quranKu);
	const buy = useApp((s) => s.buyQuranKu);
	const [msg, setMsg] = (0, import_react.useState)("");
	const poinPct = Math.min(100, points / SHOP_POINTS * 100);
	const cxpPct = Math.min(100, cxp / SHOP_CXP * 100);
	const shortPoin = Math.max(0, SHOP_POINTS - points);
	const shortCxp = Math.max(0, SHOP_CXP - cxp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold leading-tight",
				children: "Tukar QuranKu"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Hadiah ini hidup di dalam NurPray. Tidak ada berkas APK dan tidak ada tautan unduhan, supaya yang kamu buka benar-benar mushaf, bukan berkas asing."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card px-5 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-wide text-gold",
						children: "Premium"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-semibold",
						children: "QuranKu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: "Mushaf 114 surat tetap bisa dibaca tanpa menukar apa pun. QuranKu menambah perlengkapan bacanya."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-2",
						children: PERKS.map((perk) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2 text-sm",
							children: [owned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-jade" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mt-0.5 size-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: perk })]
						}, perk))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-lg font-semibold tabular-nums",
						children: [
							formatPoin(SHOP_POINTS),
							" poin + ",
							formatCxp(SHOP_CXP),
							" CXP"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Poinmu",
							value: `${formatPoin(points)} / ${formatPoin(SHOP_POINTS)}`,
							pct: poinPct
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "CXP-mu",
							value: `${formatCxp(cxp)} / ${formatCxp(SHOP_CXP)}`,
							pct: cxpPct
						})]
					}),
					owned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm",
						children: "QuranKu aktif di perangkat ini. Buka mushaf, pilih qari, atau putar kincir sepuasnya."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [shortPoin > 0 || shortCxp > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-muted",
						children: [shortPoin > 0 ? `Poin kurang ${formatPoin(shortPoin)}. ` : "", shortCxp > 0 ? `CXP kurang ${formatCxp(shortCxp)}.` : ""]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm",
						children: "Saldo sudah cukup untuk menukar."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => {
							const result = buy();
							setMsg(result === "ok" ? "QuranKu sekarang aktif." : result === "owned" ? "Sudah aktif." : "Poin atau CXP belum mencapai batas minimal.");
						},
						children: "Tukar dengan poin"
					})] }),
					msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: msg
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card px-5 py-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Jalan tercepat"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2",
						children: [
							"Satu sholat tercatat memberi ",
							formatPoin(200),
							" poin. Itu saja belum cukup. Siklus 14 hari tanpa bolong menambah ",
							formatPoin(BONUS_POINTS),
							" poin dan ",
							formatCxp(BONUS_CXP),
							" CXP — baru di situ QuranKu bisa ditukar."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						tone: "line",
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/misi",
							children: "Ke papan misi"
						})
					})
				]
			})
		]
	});
}
function Meter({ label, value, pct }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex justify-between gap-3 text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: value
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-gold-soft",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-jade",
			style: { width: `${pct}%` }
		})
	})] });
}
//#endregion
export { HadiahPage as component };

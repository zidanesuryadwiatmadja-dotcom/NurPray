import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CuFRlEu1.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function todayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function addDays(key, n) {
	const [y, m, d] = key.split("-").map(Number);
	return todayKey(new Date(y, m - 1, d + n));
}
function missionDates(start) {
	return Array.from({ length: 14 }, (_, i) => addDays(start, i));
}
function prettyDate(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, m - 1, d).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "short"
	});
}
var PRAYER_CXP = 2500;
var BONUS_POINTS = 7e4;
var BONUS_CXP = 699899;
var SHOP_POINTS = 5e4;
var SHOP_CXP = 677e3;
var PRAYERS = [
	{
		id: "subuh",
		label: "Subuh",
		key: "Fajr"
	},
	{
		id: "dzuhur",
		label: "Dzuhur",
		key: "Dhuhr"
	},
	{
		id: "ashar",
		label: "Ashar",
		key: "Asr"
	},
	{
		id: "maghrib",
		label: "Maghrib",
		key: "Maghrib"
	},
	{
		id: "isya",
		label: "Isya",
		key: "Isha"
	}
];
function prayerCount(logs, date) {
	const list = logs[date];
	return Array.isArray(list) ? list.length : 0;
}
function phaseOf(start, logs, today) {
	if (!start || !today) return "idle";
	const days = missionDates(start);
	if (days.every((d) => prayerCount(logs, d) >= 5)) return "complete";
	if (today > days[13]) return "expired";
	if (today < start) return "idle";
	if (days.some((d) => d < today && prayerCount(logs, d) < 5)) return "bolong";
	return "active";
}
function completeDays(start, logs) {
	if (!start) return 0;
	return missionDates(start).filter((d) => prayerCount(logs, d) >= 5).length;
}
function inWindow(start, today) {
	if (!start || !today) return false;
	return missionDates(start).includes(today);
}
var initial = {
	points: 0,
	cxp: 0,
	missionStart: null,
	logs: {},
	bonusClaimedFor: null,
	cycles: 0,
	quranKu: false,
	bookmarks: [],
	favs: [],
	niats: [],
	lastNiatDate: null,
	city: "Gresik",
	name: "",
	spinDate: null,
	spins: 0,
	qari: "05",
	night: false,
	arabSize: 1
};
function sameMark(a, surah, ayah) {
	return a.surah === surah && a.ayah === ayah;
}
var useApp = create()(persist((set, get) => ({
	...initial,
	togglePrayer: (id) => set((state) => {
		const today = todayKey();
		if (!state.missionStart || !inWindow(state.missionStart, today)) return state;
		const current = state.logs[today] ?? [];
		if (current.includes(id)) return state;
		const logs = {
			...state.logs,
			[today]: [...current, id]
		};
		let points = state.points + 200;
		let cxp = state.cxp + PRAYER_CXP;
		let bonusClaimedFor = state.bonusClaimedFor;
		let cycles = state.cycles;
		if (missionDates(state.missionStart).every((d) => prayerCount(logs, d) >= 5) && bonusClaimedFor !== state.missionStart) {
			points += BONUS_POINTS;
			cxp += BONUS_CXP;
			bonusClaimedFor = state.missionStart;
			cycles += 1;
		}
		return {
			logs,
			points,
			cxp,
			bonusClaimedFor,
			cycles
		};
	}),
	startMission: () => set((state) => {
		const today = todayKey();
		if (phaseOf(state.missionStart, state.logs, today) === "active") return state;
		return { missionStart: today };
	}),
	buyQuranKu: () => {
		const state = get();
		if (state.quranKu) return "owned";
		if (state.points < 5e4 || state.cxp < 677e3) return "short";
		set({
			quranKu: true,
			points: state.points - SHOP_POINTS,
			cxp: state.cxp - SHOP_CXP
		});
		return "ok";
	},
	addNiat: ({ pantiId, nominal, method, note }) => {
		const state = get();
		const today = todayKey();
		const bonus = state.lastNiatDate !== today;
		set({
			niats: [{
				id: typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `np-${Date.now()}`,
				at: (/* @__PURE__ */ new Date()).toISOString(),
				pantiId,
				nominal,
				method,
				note: note.trim().slice(0, 80)
			}, ...state.niats].slice(0, 40),
			lastNiatDate: today,
			points: state.points + (bonus ? 25 : 0)
		});
		return { bonus };
	},
	toggleBookmark: (surah, ayah) => {
		const state = get();
		if (state.bookmarks.some((b) => sameMark(b, surah, ayah))) {
			set({ bookmarks: state.bookmarks.filter((b) => !sameMark(b, surah, ayah)) });
			return "removed";
		}
		if (!state.quranKu && state.bookmarks.length >= 5) return "full";
		set({ bookmarks: [...state.bookmarks, {
			surah,
			ayah
		}] });
		return "added";
	},
	toggleFav: (n) => {
		const state = get();
		if (state.favs.includes(n)) {
			set({ favs: state.favs.filter((x) => x !== n) });
			return "removed";
		}
		if (!state.quranKu && state.favs.length >= 5) return "full";
		set({ favs: [...state.favs, n] });
		return "added";
	},
	recordSpin: () => {
		const state = get();
		const today = todayKey();
		const used = state.spinDate === today ? state.spins : 0;
		if (!state.quranKu && used >= 3) return false;
		set({
			spinDate: today,
			spins: used + 1
		});
		return true;
	},
	spinsLeft: () => {
		const state = get();
		if (state.quranKu) return 99;
		const today = todayKey();
		const used = state.spinDate === today ? state.spins : 0;
		return Math.max(0, 3 - used);
	},
	setCity: (city) => set({ city }),
	setName: (name) => set({ name: name.slice(0, 24) }),
	setQari: (qari) => set({ qari }),
	setNight: (night) => {
		if (night && !get().quranKu) return;
		set({ night });
	},
	setArabSize: (arabSize) => set({ arabSize }),
	claimIfReady: () => set((state) => {
		if (!state.missionStart || state.bonusClaimedFor === state.missionStart) return state;
		if (!missionDates(state.missionStart).every((d) => prayerCount(state.logs, d) >= 5)) return state;
		return {
			points: state.points + BONUS_POINTS,
			cxp: state.cxp + BONUS_CXP,
			bonusClaimedFor: state.missionStart,
			cycles: state.cycles + 1
		};
	}),
	resetAll: () => set({ ...initial })
}), {
	name: "nurpray-v1",
	skipHydration: true,
	storage: createJSONStorage(() => ({
		getItem: (name) => typeof window === "undefined" ? null : localStorage.getItem(name),
		setItem: (name, value) => {
			if (typeof window !== "undefined") localStorage.setItem(name, value);
		},
		removeItem: (name) => {
			if (typeof window !== "undefined") localStorage.removeItem(name);
		}
	})),
	partialize: (state) => ({
		points: state.points,
		cxp: state.cxp,
		missionStart: state.missionStart,
		logs: state.logs,
		bonusClaimedFor: state.bonusClaimedFor,
		cycles: state.cycles,
		quranKu: state.quranKu,
		bookmarks: state.bookmarks,
		favs: state.favs,
		niats: state.niats,
		lastNiatDate: state.lastNiatDate,
		city: state.city,
		name: state.name,
		spinDate: state.spinDate,
		spins: state.spins,
		qari: state.qari,
		night: state.night,
		arabSize: state.arabSize
	})
}));
//#endregion
export { SHOP_CXP as a, completeDays as c, phaseOf as d, prayerCount as f, useApp as h, PRAYER_CXP as i, inWindow as l, todayKey as m, BONUS_POINTS as n, SHOP_POINTS as o, prettyDate as p, PRAYERS as r, cn as s, BONUS_CXP as t, missionDates as u };

//#region node_modules/.nitro/vite/services/ssr/assets/surahs-0zATGrFG.js
var SURAHS = [
	{
		"nomor": 1,
		"latin": "Al-Fatihah",
		"arti": "Pembukaan",
		"ayat": 7,
		"turun": "Mekah",
		"arab": "الفاتحة"
	},
	{
		"nomor": 2,
		"latin": "Al-Baqarah",
		"arti": "Sapi",
		"ayat": 286,
		"turun": "Madinah",
		"arab": "البقرة"
	},
	{
		"nomor": 3,
		"latin": "Ali 'Imran",
		"arti": "Keluarga Imran",
		"ayat": 200,
		"turun": "Madinah",
		"arab": "اٰل عمران"
	},
	{
		"nomor": 4,
		"latin": "An-Nisa'",
		"arti": "Wanita",
		"ayat": 176,
		"turun": "Madinah",
		"arab": "النساۤء"
	},
	{
		"nomor": 5,
		"latin": "Al-Ma'idah",
		"arti": "Hidangan",
		"ayat": 120,
		"turun": "Madinah",
		"arab": "الماۤئدة"
	},
	{
		"nomor": 6,
		"latin": "Al-An'am",
		"arti": "Binatang Ternak",
		"ayat": 165,
		"turun": "Mekah",
		"arab": "الانعام"
	},
	{
		"nomor": 7,
		"latin": "Al-A'raf",
		"arti": "Tempat Tertinggi",
		"ayat": 206,
		"turun": "Mekah",
		"arab": "الاعراف"
	},
	{
		"nomor": 8,
		"latin": "Al-Anfal",
		"arti": "Rampasan Perang",
		"ayat": 75,
		"turun": "Madinah",
		"arab": "الانفال"
	},
	{
		"nomor": 9,
		"latin": "At-Taubah",
		"arti": "Pengampunan",
		"ayat": 129,
		"turun": "Madinah",
		"arab": "التوبة"
	},
	{
		"nomor": 10,
		"latin": "Yunus",
		"arti": "Yunus",
		"ayat": 109,
		"turun": "Mekah",
		"arab": "يونس"
	},
	{
		"nomor": 11,
		"latin": "Hud",
		"arti": "Hud",
		"ayat": 123,
		"turun": "Mekah",
		"arab": "هود"
	},
	{
		"nomor": 12,
		"latin": "Yusuf",
		"arti": "Yusuf",
		"ayat": 111,
		"turun": "Mekah",
		"arab": "يوسف"
	},
	{
		"nomor": 13,
		"latin": "Ar-Ra'd",
		"arti": "Guruh",
		"ayat": 43,
		"turun": "Madinah",
		"arab": "الرّعد"
	},
	{
		"nomor": 14,
		"latin": "Ibrahim",
		"arti": "Ibrahim",
		"ayat": 52,
		"turun": "Mekah",
		"arab": "ابرٰهيم"
	},
	{
		"nomor": 15,
		"latin": "Al-Hijr",
		"arti": "Hijr",
		"ayat": 99,
		"turun": "Mekah",
		"arab": "الحجر"
	},
	{
		"nomor": 16,
		"latin": "An-Nahl",
		"arti": "Lebah",
		"ayat": 128,
		"turun": "Mekah",
		"arab": "النحل"
	},
	{
		"nomor": 17,
		"latin": "Al-Isra'",
		"arti": "Memperjalankan Malam Hari",
		"ayat": 111,
		"turun": "Mekah",
		"arab": "الاسراۤء"
	},
	{
		"nomor": 18,
		"latin": "Al-Kahf",
		"arti": "Goa",
		"ayat": 110,
		"turun": "Mekah",
		"arab": "الكهف"
	},
	{
		"nomor": 19,
		"latin": "Maryam",
		"arti": "Maryam",
		"ayat": 98,
		"turun": "Mekah",
		"arab": "مريم"
	},
	{
		"nomor": 20,
		"latin": "Taha",
		"arti": "Taha",
		"ayat": 135,
		"turun": "Mekah",
		"arab": "طٰهٰ"
	},
	{
		"nomor": 21,
		"latin": "Al-Anbiya'",
		"arti": "Para Nabi",
		"ayat": 112,
		"turun": "Mekah",
		"arab": "الانبياۤء"
	},
	{
		"nomor": 22,
		"latin": "Al-Hajj",
		"arti": "Haji",
		"ayat": 78,
		"turun": "Madinah",
		"arab": "الحج"
	},
	{
		"nomor": 23,
		"latin": "Al-Mu'minun",
		"arti": "Orang-Orang Mukmin",
		"ayat": 118,
		"turun": "Mekah",
		"arab": "المؤمنون"
	},
	{
		"nomor": 24,
		"latin": "An-Nur",
		"arti": "Cahaya",
		"ayat": 64,
		"turun": "Madinah",
		"arab": "النّور"
	},
	{
		"nomor": 25,
		"latin": "Al-Furqan",
		"arti": "Pembeda",
		"ayat": 77,
		"turun": "Mekah",
		"arab": "الفرقان"
	},
	{
		"nomor": 26,
		"latin": "Asy-Syu'ara'",
		"arti": "Para Penyair",
		"ayat": 227,
		"turun": "Mekah",
		"arab": "الشعراۤء"
	},
	{
		"nomor": 27,
		"latin": "An-Naml",
		"arti": "Semut-semut",
		"ayat": 93,
		"turun": "Mekah",
		"arab": "النمل"
	},
	{
		"nomor": 28,
		"latin": "Al-Qasas",
		"arti": "Kisah-Kisah",
		"ayat": 88,
		"turun": "Mekah",
		"arab": "القصص"
	},
	{
		"nomor": 29,
		"latin": "Al-'Ankabut",
		"arti": "Laba-Laba",
		"ayat": 69,
		"turun": "Mekah",
		"arab": "العنكبوت"
	},
	{
		"nomor": 30,
		"latin": "Ar-Rum",
		"arti": "Romawi",
		"ayat": 60,
		"turun": "Mekah",
		"arab": "الرّوم"
	},
	{
		"nomor": 31,
		"latin": "Luqman",
		"arti": "Luqman",
		"ayat": 34,
		"turun": "Mekah",
		"arab": "لقمٰن"
	},
	{
		"nomor": 32,
		"latin": "As-Sajdah",
		"arti": "Sajdah",
		"ayat": 30,
		"turun": "Mekah",
		"arab": "السّجدة"
	},
	{
		"nomor": 33,
		"latin": "Al-Ahzab",
		"arti": "Golongan Yang Bersekutu",
		"ayat": 73,
		"turun": "Madinah",
		"arab": "الاحزاب"
	},
	{
		"nomor": 34,
		"latin": "Saba'",
		"arti": "Saba'",
		"ayat": 54,
		"turun": "Mekah",
		"arab": "سبأ"
	},
	{
		"nomor": 35,
		"latin": "Fatir",
		"arti": "Maha Pencipta",
		"ayat": 45,
		"turun": "Mekah",
		"arab": "فاطر"
	},
	{
		"nomor": 36,
		"latin": "Yasin",
		"arti": "Yasin",
		"ayat": 83,
		"turun": "Mekah",
		"arab": "يٰسۤ"
	},
	{
		"nomor": 37,
		"latin": "As-Saffat",
		"arti": "Barisan-Barisan",
		"ayat": 182,
		"turun": "Mekah",
		"arab": "الصّٰۤفّٰت"
	},
	{
		"nomor": 38,
		"latin": "Sad",
		"arti": "Sad",
		"ayat": 88,
		"turun": "Mekah",
		"arab": "ص"
	},
	{
		"nomor": 39,
		"latin": "Az-Zumar",
		"arti": "Rombongan",
		"ayat": 75,
		"turun": "Mekah",
		"arab": "الزمر"
	},
	{
		"nomor": 40,
		"latin": "Ghafir",
		"arti": "Maha Pengampun",
		"ayat": 85,
		"turun": "Mekah",
		"arab": "غافر"
	},
	{
		"nomor": 41,
		"latin": "Fussilat",
		"arti": "Yang Dijelaskan",
		"ayat": 54,
		"turun": "Mekah",
		"arab": "فصّلت"
	},
	{
		"nomor": 42,
		"latin": "Asy-Syura",
		"arti": "Musyawarah",
		"ayat": 53,
		"turun": "Mekah",
		"arab": "الشورى"
	},
	{
		"nomor": 43,
		"latin": "Az-Zukhruf",
		"arti": "Perhiasan",
		"ayat": 89,
		"turun": "Mekah",
		"arab": "الزخرف"
	},
	{
		"nomor": 44,
		"latin": "Ad-Dukhan",
		"arti": "Kabut",
		"ayat": 59,
		"turun": "Mekah",
		"arab": "الدخان"
	},
	{
		"nomor": 45,
		"latin": "Al-Jasiyah",
		"arti": "Berlutut",
		"ayat": 37,
		"turun": "Mekah",
		"arab": "الجاثية"
	},
	{
		"nomor": 46,
		"latin": "Al-Ahqaf",
		"arti": "Bukit Pasir",
		"ayat": 35,
		"turun": "Mekah",
		"arab": "الاحقاف"
	},
	{
		"nomor": 47,
		"latin": "Muhammad",
		"arti": "Muhammad",
		"ayat": 38,
		"turun": "Madinah",
		"arab": "محمّد"
	},
	{
		"nomor": 48,
		"latin": "Al-Fath",
		"arti": "Kemenangan",
		"ayat": 29,
		"turun": "Madinah",
		"arab": "الفتح"
	},
	{
		"nomor": 49,
		"latin": "Al-Hujurat",
		"arti": "Kamar-Kamar",
		"ayat": 18,
		"turun": "Madinah",
		"arab": "الحجرٰت"
	},
	{
		"nomor": 50,
		"latin": "Qaf",
		"arti": "Qaf",
		"ayat": 45,
		"turun": "Mekah",
		"arab": "ق"
	},
	{
		"nomor": 51,
		"latin": "Az-Zariyat",
		"arti": "Angin yang Menerbangkan",
		"ayat": 60,
		"turun": "Mekah",
		"arab": "الذّٰريٰت"
	},
	{
		"nomor": 52,
		"latin": "At-Tur",
		"arti": "Bukit Tursina",
		"ayat": 49,
		"turun": "Mekah",
		"arab": "الطور"
	},
	{
		"nomor": 53,
		"latin": "An-Najm",
		"arti": "Bintang",
		"ayat": 62,
		"turun": "Mekah",
		"arab": "النجم"
	},
	{
		"nomor": 54,
		"latin": "Al-Qamar",
		"arti": "Bulan",
		"ayat": 55,
		"turun": "Mekah",
		"arab": "القمر"
	},
	{
		"nomor": 55,
		"latin": "Ar-Rahman",
		"arti": "Maha Pengasih",
		"ayat": 78,
		"turun": "Madinah",
		"arab": "الرحمن"
	},
	{
		"nomor": 56,
		"latin": "Al-Waqi'ah",
		"arti": "Hari Kiamat",
		"ayat": 96,
		"turun": "Mekah",
		"arab": "الواقعة"
	},
	{
		"nomor": 57,
		"latin": "Al-Hadid",
		"arti": "Besi",
		"ayat": 29,
		"turun": "Madinah",
		"arab": "الحديد"
	},
	{
		"nomor": 58,
		"latin": "Al-Mujadilah",
		"arti": "Gugatan",
		"ayat": 22,
		"turun": "Madinah",
		"arab": "المجادلة"
	},
	{
		"nomor": 59,
		"latin": "Al-Hasyr",
		"arti": "Pengusiran",
		"ayat": 24,
		"turun": "Madinah",
		"arab": "الحشر"
	},
	{
		"nomor": 60,
		"latin": "Al-Mumtahanah",
		"arti": "Wanita Yang Diuji",
		"ayat": 13,
		"turun": "Madinah",
		"arab": "الممتحنة"
	},
	{
		"nomor": 61,
		"latin": "As-Saff",
		"arti": "Barisan",
		"ayat": 14,
		"turun": "Madinah",
		"arab": "الصّفّ"
	},
	{
		"nomor": 62,
		"latin": "Al-Jumu'ah",
		"arti": "Jumat",
		"ayat": 11,
		"turun": "Madinah",
		"arab": "الجمعة"
	},
	{
		"nomor": 63,
		"latin": "Al-Munafiqun",
		"arti": "Orang-Orang Munafik",
		"ayat": 11,
		"turun": "Madinah",
		"arab": "المنٰفقون"
	},
	{
		"nomor": 64,
		"latin": "At-Tagabun",
		"arti": "Pengungkapan Kesalahan",
		"ayat": 18,
		"turun": "Madinah",
		"arab": "التغابن"
	},
	{
		"nomor": 65,
		"latin": "At-Talaq",
		"arti": "Talak",
		"ayat": 12,
		"turun": "Madinah",
		"arab": "الطلاق"
	},
	{
		"nomor": 66,
		"latin": "At-Tahrim",
		"arti": "Pengharaman",
		"ayat": 12,
		"turun": "Madinah",
		"arab": "التحريم"
	},
	{
		"nomor": 67,
		"latin": "Al-Mulk",
		"arti": "Kerajaan",
		"ayat": 30,
		"turun": "Mekah",
		"arab": "الملك"
	},
	{
		"nomor": 68,
		"latin": "Al-Qalam",
		"arti": "Pena",
		"ayat": 52,
		"turun": "Mekah",
		"arab": "القلم"
	},
	{
		"nomor": 69,
		"latin": "Al-Haqqah",
		"arti": "Hari Kiamat",
		"ayat": 52,
		"turun": "Mekah",
		"arab": "الحاۤقّة"
	},
	{
		"nomor": 70,
		"latin": "Al-Ma'arij",
		"arti": "Tempat Naik",
		"ayat": 44,
		"turun": "Mekah",
		"arab": "المعارج"
	},
	{
		"nomor": 71,
		"latin": "Nuh",
		"arti": "Nuh",
		"ayat": 28,
		"turun": "Mekah",
		"arab": "نوح"
	},
	{
		"nomor": 72,
		"latin": "Al-Jinn",
		"arti": "Jin",
		"ayat": 28,
		"turun": "Mekah",
		"arab": "الجن"
	},
	{
		"nomor": 73,
		"latin": "Al-Muzzammil",
		"arti": "Orang Yang Berselimut",
		"ayat": 20,
		"turun": "Mekah",
		"arab": "المزّمّل"
	},
	{
		"nomor": 74,
		"latin": "Al-Muddassir",
		"arti": "Orang Yang Berkemul",
		"ayat": 56,
		"turun": "Mekah",
		"arab": "المدّثّر"
	},
	{
		"nomor": 75,
		"latin": "Al-Qiyamah",
		"arti": "Hari Kiamat",
		"ayat": 40,
		"turun": "Mekah",
		"arab": "القيٰمة"
	},
	{
		"nomor": 76,
		"latin": "Al-Insan",
		"arti": "Manusia",
		"ayat": 31,
		"turun": "Madinah",
		"arab": "الانسان"
	},
	{
		"nomor": 77,
		"latin": "Al-Mursalat",
		"arti": "Malaikat Yang Diutus",
		"ayat": 50,
		"turun": "Mekah",
		"arab": "المرسلٰت"
	},
	{
		"nomor": 78,
		"latin": "An-Naba'",
		"arti": "Berita Besar",
		"ayat": 40,
		"turun": "Mekah",
		"arab": "النبأ"
	},
	{
		"nomor": 79,
		"latin": "An-Nazi'at",
		"arti": "Malaikat Yang Mencabut",
		"ayat": 46,
		"turun": "Mekah",
		"arab": "النّٰزعٰت"
	},
	{
		"nomor": 80,
		"latin": "'Abasa",
		"arti": "Bermuka Masam",
		"ayat": 42,
		"turun": "Mekah",
		"arab": "عبس"
	},
	{
		"nomor": 81,
		"latin": "At-Takwir",
		"arti": "Penggulungan",
		"ayat": 29,
		"turun": "Mekah",
		"arab": "التكوير"
	},
	{
		"nomor": 82,
		"latin": "Al-Infitar",
		"arti": "Terbelah",
		"ayat": 19,
		"turun": "Mekah",
		"arab": "الانفطار"
	},
	{
		"nomor": 83,
		"latin": "Al-Mutaffifin",
		"arti": "Orang-Orang Curang",
		"ayat": 36,
		"turun": "Mekah",
		"arab": "المطفّفين"
	},
	{
		"nomor": 84,
		"latin": "Al-Insyiqaq",
		"arti": "Terbelah",
		"ayat": 25,
		"turun": "Mekah",
		"arab": "الانشقاق"
	},
	{
		"nomor": 85,
		"latin": "Al-Buruj",
		"arti": "Gugusan Bintang",
		"ayat": 22,
		"turun": "Mekah",
		"arab": "البروج"
	},
	{
		"nomor": 86,
		"latin": "At-Tariq",
		"arti": "Yang Datang Di Malam Hari",
		"ayat": 17,
		"turun": "Mekah",
		"arab": "الطارق"
	},
	{
		"nomor": 87,
		"latin": "Al-A'la",
		"arti": "Maha Tinggi",
		"ayat": 19,
		"turun": "Mekah",
		"arab": "الاعلى"
	},
	{
		"nomor": 88,
		"latin": "Al-Gasyiyah",
		"arti": "Hari Kiamat",
		"ayat": 26,
		"turun": "Mekah",
		"arab": "الغاشية"
	},
	{
		"nomor": 89,
		"latin": "Al-Fajr",
		"arti": "Fajar",
		"ayat": 30,
		"turun": "Mekah",
		"arab": "الفجر"
	},
	{
		"nomor": 90,
		"latin": "Al-Balad",
		"arti": "Negeri",
		"ayat": 20,
		"turun": "Mekah",
		"arab": "البلد"
	},
	{
		"nomor": 91,
		"latin": "Asy-Syams",
		"arti": "Matahari",
		"ayat": 15,
		"turun": "Mekah",
		"arab": "الشمس"
	},
	{
		"nomor": 92,
		"latin": "Al-Lail",
		"arti": "Malam",
		"ayat": 21,
		"turun": "Mekah",
		"arab": "الّيل"
	},
	{
		"nomor": 93,
		"latin": "Ad-Duha",
		"arti": "Duha",
		"ayat": 11,
		"turun": "Mekah",
		"arab": "الضحى"
	},
	{
		"nomor": 94,
		"latin": "Al-Insyirah",
		"arti": "Lapang",
		"ayat": 8,
		"turun": "Mekah",
		"arab": "الشرح"
	},
	{
		"nomor": 95,
		"latin": "At-Tin",
		"arti": "Buah Tin",
		"ayat": 8,
		"turun": "Mekah",
		"arab": "التين"
	},
	{
		"nomor": 96,
		"latin": "Al-'Alaq",
		"arti": "Segumpal Darah",
		"ayat": 19,
		"turun": "Mekah",
		"arab": "العلق"
	},
	{
		"nomor": 97,
		"latin": "Al-Qadr",
		"arti": "Kemuliaan",
		"ayat": 5,
		"turun": "Mekah",
		"arab": "القدر"
	},
	{
		"nomor": 98,
		"latin": "Al-Bayyinah",
		"arti": "Bukti Nyata",
		"ayat": 8,
		"turun": "Madinah",
		"arab": "البيّنة"
	},
	{
		"nomor": 99,
		"latin": "Az-Zalzalah",
		"arti": "Guncangan",
		"ayat": 8,
		"turun": "Madinah",
		"arab": "الزلزلة"
	},
	{
		"nomor": 100,
		"latin": "Al-'Adiyat",
		"arti": "Kuda Yang Berlari Kencang",
		"ayat": 11,
		"turun": "Mekah",
		"arab": "العٰديٰت"
	},
	{
		"nomor": 101,
		"latin": "Al-Qari'ah",
		"arti": "Hari Kiamat",
		"ayat": 11,
		"turun": "Mekah",
		"arab": "القارعة"
	},
	{
		"nomor": 102,
		"latin": "At-Takasur",
		"arti": "Bermegah-Megahan",
		"ayat": 8,
		"turun": "Mekah",
		"arab": "التكاثر"
	},
	{
		"nomor": 103,
		"latin": "Al-'Asr",
		"arti": "Masa",
		"ayat": 3,
		"turun": "Mekah",
		"arab": "العصر"
	},
	{
		"nomor": 104,
		"latin": "Al-Humazah",
		"arti": "Pengumpat",
		"ayat": 9,
		"turun": "Mekah",
		"arab": "الهمزة"
	},
	{
		"nomor": 105,
		"latin": "Al-Fil",
		"arti": "Gajah",
		"ayat": 5,
		"turun": "Mekah",
		"arab": "الفيل"
	},
	{
		"nomor": 106,
		"latin": "Quraisy",
		"arti": "Quraisy",
		"ayat": 4,
		"turun": "Mekah",
		"arab": "قريش"
	},
	{
		"nomor": 107,
		"latin": "Al-Ma'un",
		"arti": "Barang Yang Berguna",
		"ayat": 7,
		"turun": "Mekah",
		"arab": "الماعون"
	},
	{
		"nomor": 108,
		"latin": "Al-Kausar",
		"arti": "Pemberian Yang Banyak",
		"ayat": 3,
		"turun": "Mekah",
		"arab": "الكوثر"
	},
	{
		"nomor": 109,
		"latin": "Al-Kafirun",
		"arti": "Orang-Orang kafir",
		"ayat": 6,
		"turun": "Mekah",
		"arab": "الكٰفرون"
	},
	{
		"nomor": 110,
		"latin": "An-Nasr",
		"arti": "Pertolongan",
		"ayat": 3,
		"turun": "Madinah",
		"arab": "النصر"
	},
	{
		"nomor": 111,
		"latin": "Al-Lahab",
		"arti": "Api Yang Bergejolak",
		"ayat": 5,
		"turun": "Mekah",
		"arab": "اللهب"
	},
	{
		"nomor": 112,
		"latin": "Al-Ikhlas",
		"arti": "Ikhlas",
		"ayat": 4,
		"turun": "Mekah",
		"arab": "الاخلاص"
	},
	{
		"nomor": 113,
		"latin": "Al-Falaq",
		"arti": "Subuh",
		"ayat": 5,
		"turun": "Madinah",
		"arab": "الفلق"
	},
	{
		"nomor": 114,
		"latin": "An-Nas",
		"arti": "Manusia",
		"ayat": 6,
		"turun": "Madinah",
		"arab": "الناس"
	}
];
//#endregion
export { SURAHS as t };

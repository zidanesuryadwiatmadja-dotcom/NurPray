import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { m as todayKey } from "./store-CuFRlEu1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-clock-MSQiqYYZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useToday() {
	const [today, setToday] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => setToday(todayKey());
		tick();
		const id = window.setInterval(tick, 3e4);
		return () => window.clearInterval(id);
	}, []);
	return today;
}
function useGreeting(name) {
	const [text, setText] = (0, import_react.useState)("Assalamu'alaikum");
	(0, import_react.useEffect)(() => {
		const hour = (/* @__PURE__ */ new Date()).getHours();
		const part = hour < 4 ? "Selamat malam" : hour < 11 ? "Selamat pagi" : hour < 15 ? "Selamat siang" : hour < 18 ? "Selamat sore" : "Selamat malam";
		const who = name.trim();
		setText(who ? `${part}, ${who}` : part);
	}, [name]);
	return text;
}
function useDailyNumber() {
	const [n, setN] = (0, import_react.useState)(1);
	(0, import_react.useEffect)(() => {
		const key = todayKey();
		let hash = 2166136261;
		for (let i = 0; i < key.length; i += 1) {
			hash ^= key.charCodeAt(i);
			hash = Math.imul(hash, 16777619);
		}
		setN(Math.abs(hash) % 777 + 1);
	}, []);
	return n;
}
function useReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const sync = () => setReduced(mq.matches);
		sync();
		mq.addEventListener("change", sync);
		return () => mq.removeEventListener("change", sync);
	}, []);
	return reduced;
}
//#endregion
export { useToday as i, useGreeting as n, useReducedMotion as r, useDailyNumber as t };

import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as useApp, s as cn } from "./store-CuFRlEu1.mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Bookmark } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-CgmPagmD.mjs";
import { i as searchMotifs, n as MOTIF_READY, r as motif, t as CATS } from "./motivations-DiKR0zzT.mjs";
import { t as useDailyNumber } from "./use-clock-MSQiqYYZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/motivasi-DKzLL2MF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MotivasiPage() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("Semua");
	const [count, setCount] = (0, import_react.useState)(12);
	const [note, setNote] = (0, import_react.useState)("");
	const [pin, setPin] = (0, import_react.useState)(null);
	const daily = useDailyNumber();
	const favs = useApp((s) => s.favs);
	const toggleFav = useApp((s) => s.toggleFav);
	const items = (0, import_react.useMemo)(() => searchMotifs(query, cat), [query, cat]);
	const pinned = pin && pin >= 1 && pin <= 777 ? motif(pin) : null;
	(0, import_react.useEffect)(() => {
		const match = window.location.hash.match(/^#m-(\d+)$/);
		if (!match) return;
		const n = Number(match[1]);
		if (n >= 1 && n <= 777) setPin(n);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold leading-tight",
					children: "777 renungan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Bacaan harian tentang sholat, ngaji, sedekah, dakwah, dan akhlak. Ini bukan kumpulan hadits. Jika ada isyarat ayat, itu makna ringkas, bukan tafsir."
				}),
				!MOTIF_READY ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm",
					children: "Daftar renungan belum utuh."
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DailyCard, {
				n: daily,
				saved: favs.includes(daily),
				onSave: () => save(daily, toggleFav, setNote)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				className: "flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					const n = Number(query);
					if (Number.isInteger(n) && n >= 1 && n <= 777) {
						setPin(n);
						setQuery("");
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: query,
					onChange: (event) => {
						setQuery(event.target.value);
						setCount(12);
					},
					placeholder: "Cari kata atau nomor 1–777",
					inputMode: "search",
					"aria-label": "Cari renungan"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: cat === "Semua",
					onClick: () => {
						setCat("Semua");
						setCount(12);
					},
					children: "Semua"
				}), CATS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: cat === item,
					onClick: () => {
						setCat(item);
						setCount(12);
					},
					children: item
				}, item))]
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: note
			}) : null,
			pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotifCard, {
					item: pinned,
					saved: favs.includes(pinned.n),
					onSave: () => save(pinned.n, toggleFav, setNote)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					tone: "line",
					onClick: () => setPin(null),
					children: ["Tutup nomor ", pinned.n]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [items.length, " renungan"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: items.slice(0, count).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotifCard, {
					item,
					saved: favs.includes(item.n),
					onSave: () => save(item.n, toggleFav, setNote)
				}, item.n))
			}),
			count < items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				tone: "line",
				onClick: () => setCount((value) => value + 12),
				children: "Muat lagi"
			}) : null
		]
	});
}
function save(n, toggle, setNote) {
	const status = toggle(n);
	setNote(status === "full" ? `Favorit gratis penuh (5). QuranKu menyimpan tanpa batas.` : status === "added" ? `Renungan ${n} disimpan.` : `Renungan ${n} dilepas.`);
}
function DailyCard({ n, saved, onSave }) {
	const item = motif(n);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "card border-l-4 border-l-jade px-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs font-semibold tracking-wide text-jade",
			children: ["Hari ini · nomor ", item.n]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotifBody, {
			item,
			saved,
			onSave
		})]
	});
}
function MotifCard({ item, saved, onSave }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		id: `m-${item.n}`,
		className: "card px-4 py-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotifBody, {
			item,
			saved,
			onSave
		})
	});
}
function MotifBody({ item, saved, onSave }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-semibold text-muted",
				children: [
					item.n,
					" · ",
					item.cat
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex size-11 shrink-0 items-center justify-center",
				onClick: onSave,
				"aria-pressed": saved,
				"aria-label": "Simpan renungan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn("size-4", saved && "fill-jade text-jade") })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-semibold leading-snug",
			children: item.lead
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm",
			children: item.support
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 border-t border-line pt-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: "Amal kecil. "
			}), item.amal]
		})
	] });
}
function Chip({ children, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: cn("min-h-11 shrink-0 rounded-full border px-3 text-sm", on ? "border-jade bg-jade text-surface" : "border-line bg-surface text-ink"),
		children
	});
}
//#endregion
export { MotivasiPage as component };
